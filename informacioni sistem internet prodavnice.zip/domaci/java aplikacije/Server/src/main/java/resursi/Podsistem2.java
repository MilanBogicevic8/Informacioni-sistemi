/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package resursi;

import entities.Artikal;
import entities.Kategorija;
import entities.Korpa;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.StringTokenizer;
import javax.annotation.Resource;
import javax.jms.ConnectionFactory;
import javax.jms.JMSConsumer;
import javax.jms.JMSContext;
import javax.jms.JMSException;
import javax.jms.JMSProducer;
import javax.jms.Message;
import javax.jms.ObjectMessage;
import javax.jms.Queue;
import javax.jms.TextMessage;
import javax.jms.Topic;
import javax.ws.rs.DELETE;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.GenericEntity;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.Response;
import static javax.ws.rs.core.Response.Status.OK;
import komanda.Komanda;
import komanda.KomandaBrisanjeIzKorpe;
import komanda.KomandaDodajArtikleUKorpu;
import komanda.KomandaDodajKategoriju;
import komanda.KomandaDodajPopust;
import komanda.KomandaDohvatiArtikleKorisnika;
import komanda.KomandaDohvatiKategorije;
import komanda.KomandaDohvatiKorpu;
import komanda.KomandaKreiranjeArtikla;
import komanda.KomandaPromeniCenu;

/**
 *
 * @author Korisnik
 */
@Path("podsistem2")
public class Podsistem2 {
    
    @Resource(lookup = "connFactory1")
    ConnectionFactory connectionFactory;
    
    @Resource(lookup = "server1")
    Topic topic;
     
    @Resource(lookup = "red1")
    Queue queue;
    
    
    @POST
    @Path("kreirajKategoriju")
    public Response kreirajKategoriju(@FormParam("kategorija")String kategorija,@FormParam("nadKategorija")String nadKategorija) throws JMSException{
        JMSContext context = connectionFactory.createContext();
        JMSProducer producer = context.createProducer();
        JMSConsumer consumer = context.createConsumer(queue);
        
        Komanda komanda=new KomandaDodajKategoriju(kategorija,nadKategorija);
        ObjectMessage obj=context.createObjectMessage(komanda);
        obj.setIntProperty("zahtev",5);
        obj.setIntProperty("pod", 2);
        
        producer.send(topic,obj);
        
        Message message = consumer.receive();//odgovor
         if (!(message instanceof TextMessage)){
                return Response.status(Response.Status.BAD_REQUEST).entity("Pogresna poruka zbog tipa").build();
         }
         
         TextMessage resMsg = (TextMessage) message;
         String res = resMsg.getText();
         int ret = resMsg.getIntProperty("status");
         if (ret != 0) 
             return Response.status(Response.Status.BAD_REQUEST).entity(res).build();
         else
             return Response.status(OK).entity("Dodali smo kategoriju").build();
        
        
    }
    
    
    @GET
    @Path("dohvatiKategorije")
    public Response dohvatiKategorije() throws JMSException{
        ObjectMessage objMsg=null;
        
        JMSContext context = connectionFactory.createContext();
        JMSProducer producer = context.createProducer();
        JMSConsumer consumer = context.createConsumer(queue);
            
       Komanda komanda=new KomandaDohvatiKategorije();
       ObjectMessage obj=context.createObjectMessage(komanda);
       obj.setIntProperty("zahtev",14);
       obj.setIntProperty("pod", 2);
        
       producer.send(topic,obj);
       
       Message mess = consumer.receive();
       if (!(mess instanceof ObjectMessage)){
           return Response.status(Response.Status.BAD_REQUEST).entity("Pogresio si tip").build();
         }
        objMsg = (ObjectMessage) mess;
        
        return Response.status(OK).entity(new GenericEntity<List<Kategorija>>((ArrayList<Kategorija>) objMsg.getObject()){}).build();
    }
    
    @GET
    @Path("dohvatiArtikleKorisnika/{ime}/{prezime}")
    public Response dohvatiArtikleKorisnika(@PathParam("ime")String ime,@PathParam("prezime")String prezime) throws JMSException{
        
        //@Context HttpHeaders httpHeaders
        /*List<String> authHeaderValues = httpHeaders.getRequestHeader("Authorization");
        
        if(authHeaderValues != null && !authHeaderValues.isEmpty()){
            String authHeaderValue = authHeaderValues.get(0);
            String[] decodedAuthHeaderValue = new String(Base64.getDecoder().decode(authHeaderValue.replaceFirst("Basic ", "")),StandardCharsets.UTF_8).split(":");
            String ime=decodedAuthHeaderValue[0];
            String prezime=decodedAuthHeaderValue[1];
           */ 
            
            
            
        JMSContext context = connectionFactory.createContext();
        JMSProducer producer = context.createProducer();
        JMSConsumer consumer = context.createConsumer(queue);
        
        TextMessage msg = context.createTextMessage("zahtev");
        msg.setIntProperty("zahtev", 15);
        msg.setIntProperty("pod", 1);
        
        msg.setStringProperty("ime", ime);
        msg.setStringProperty("prezime", prezime);
        
        producer.send(topic, msg);
        
        Message message = consumer.receive();//odgovor
        if (!(message instanceof TextMessage)){
                return Response.status(Response.Status.BAD_REQUEST).entity("Pogresna poruka zbog tipa").build();
         }
         
         TextMessage resMsg = (TextMessage) message;
         String res = resMsg.getText();
         int ret = resMsg.getIntProperty("status");
         if (ret != 0) 
             return Response.status(Response.Status.BAD_REQUEST).entity(res).build();
        int flag=resMsg.getIntProperty("korisnik");
        
        if(flag<0){
             return Response.status(Response.Status.BAD_REQUEST).entity("Nema tog korisnika").build();
        }
        
        ObjectMessage objMsg=null;
        
        Komanda komanda=new KomandaDohvatiArtikleKorisnika(flag);
        
       ObjectMessage obj=context.createObjectMessage(komanda);
       obj.setIntProperty("zahtev",15);
       obj.setIntProperty("pod", 2);
        
       producer.send(topic,obj);
       
       Message mess = consumer.receive();
       if (!(mess instanceof ObjectMessage)){
           return Response.status(Response.Status.BAD_REQUEST).entity("Pogresio si tip").build();
         }
        objMsg = (ObjectMessage) mess;
        
        return Response.status(OK).entity(new GenericEntity<List<Artikal>>((ArrayList<Artikal>) objMsg.getObject()){}).build();
    
        
    }
        
       //return Response.status(Response.Status.BAD_REQUEST).entity("Posalji kredencijale").build();
    
//}

    
    
    @POST
    @Path("dodajArtikal")
    public Response dodajArtikal(@FormParam("naziv")String naziv,@FormParam("opis")String opis,@FormParam("cena")String cena,
                                 @FormParam("popust")String popust,@FormParam("korisnik")String korisnik,@FormParam("idkategorija")String idkategorije) throws JMSException{
        
       JMSContext context = connectionFactory.createContext();
       JMSProducer producer = context.createProducer();
       JMSConsumer consumer = context.createConsumer(queue); 
       
       TextMessage msg = context.createTextMessage("zahtev");
       msg.setIntProperty("zahtev", 6);
       msg.setIntProperty("pod", 1);
       
       msg.setStringProperty("korisnik", korisnik);
       
       producer.send(topic, msg);
       
        Message message = consumer.receive();//odgovor
        if (!(message instanceof TextMessage)){
                return Response.status(Response.Status.BAD_REQUEST).entity("Pogresna poruka zbog tipa").build();
        }
        
        TextMessage resMsg = (TextMessage) message;
        String res = resMsg.getText();
         int ret = resMsg.getIntProperty("status");
         if (ret != 0) 
             return Response.status(Response.Status.BAD_REQUEST).entity(res).build();
        int flag=resMsg.getIntProperty("ima");
        
        if(flag<0){
             return Response.status(Response.Status.BAD_REQUEST).entity("Nema tog korisnika").build();
        }
        
        ObjectMessage objMsg=null;
        
        Komanda komanda=new KomandaKreiranjeArtikla(naziv,opis,cena,popust,korisnik,idkategorije);
        
       ObjectMessage obj=context.createObjectMessage(komanda);
       obj.setIntProperty("zahtev",6);
       obj.setIntProperty("pod", 2);
       
       producer.send(topic,obj);
       
       
       Message mess = consumer.receive();//odgovor
        if (!(mess instanceof TextMessage)){
                return Response.status(Response.Status.BAD_REQUEST).entity("Pogresna poruka zbog tipa").build();
         }
         
         TextMessage resM = (TextMessage) mess;
         String re = resM.getText();
         int retu = resM.getIntProperty("status");
         if (retu != 0) 
             return Response.status(Response.Status.BAD_REQUEST).entity(re).build();
         else
             return Response.status(OK).entity("Dodali smo artikal").build();
    }
    
    @POST
    @Path("dodajPopust")
    public Response dodajPopust(@FormParam("idartikal")String idartikal,@FormParam("popust")String popust) throws JMSException{
        JMSContext context = connectionFactory.createContext();
        JMSProducer producer = context.createProducer();
        JMSConsumer consumer = context.createConsumer(queue);
        
        ObjectMessage objMsg=null;
        
        Komanda komanda=new KomandaDodajPopust(idartikal,popust);
        ObjectMessage obj=context.createObjectMessage(komanda);
        obj.setIntProperty("zahtev",8);
        obj.setIntProperty("pod", 2);
        
        producer.send(topic,obj);
        
        
        Message mess = consumer.receive();//odgovor
        if (!(mess instanceof TextMessage)){
                return Response.status(Response.Status.BAD_REQUEST).entity("Pogresna poruka zbog tipa").build();
         }
        
        
        TextMessage resM = (TextMessage) mess;
         String re = resM.getText();
         int retu = resM.getIntProperty("status");
         if (retu != 0) 
             return Response.status(Response.Status.BAD_REQUEST).entity(re).build();
         else
             return Response.status(OK).entity("Dodali smo artikal").build();
    }
    
    
    @POST
    @Path("promeniCenu")
    public Response promeniCenu(@FormParam("idartikal")String idartikal,@FormParam("cena")String cena) throws JMSException{
        
        JMSContext context = connectionFactory.createContext();
        JMSProducer producer = context.createProducer();
        JMSConsumer consumer = context.createConsumer(queue);
        
        ObjectMessage objMsg=null;
        
        Komanda komanda=new KomandaPromeniCenu(idartikal, cena);
        
        ObjectMessage obj=context.createObjectMessage(komanda);
        obj.setIntProperty("zahtev",7);
        obj.setIntProperty("pod", 2);
        
        producer.send(topic,obj);
        
        Message mess = consumer.receive();//odgovor
        if (!(mess instanceof TextMessage)){
                return Response.status(Response.Status.BAD_REQUEST).entity("Pogresna poruka zbog tipa").build();
         }
        
        TextMessage resM = (TextMessage) mess;
         String re = resM.getText();
         int retu = resM.getIntProperty("status");
         if (retu != 0) 
             return Response.status(Response.Status.BAD_REQUEST).entity(re).build();
         else
             return Response.status(OK).entity("Dodali smo artikal").build();
        
    }
    
    
    @POST
    @Path("dodajKorpu")
    public Response dodajUKorpu(@FormParam("korisnik")String korisnik,@FormParam("artikal")String artikal,@FormParam("kolicina")String kolicina) throws JMSException{
        JMSContext context = connectionFactory.createContext();
        JMSProducer producer = context.createProducer();
        JMSConsumer consumer = context.createConsumer(queue);
        
        TextMessage msg = context.createTextMessage("zahtev");
        msg.setIntProperty("zahtev", 9);
        msg.setIntProperty("pod", 1);
        
        msg.setStringProperty("idkori", korisnik);
        
        producer.send(topic, msg);
        
        Message message = consumer.receive();//odgovor
        if (!(message instanceof TextMessage)){
                return Response.status(Response.Status.BAD_REQUEST).entity("Pogresna poruka zbog tipa").build();
         }
        
        int flag=message.getIntProperty("ima");
        
        if(flag<0){
             return Response.status(Response.Status.BAD_REQUEST).entity("Nema tog korisnika").build();
        }
        
        ObjectMessage objMsg=null;
        
        Komanda komanda=new KomandaDodajArtikleUKorpu(artikal,kolicina,korisnik);
        
        ObjectMessage obj=context.createObjectMessage(komanda);
        obj.setIntProperty("zahtev",9);
        obj.setIntProperty("pod", 2);
       
        producer.send(topic,obj);
       
       
        Message mess = consumer.receive();//odgovor
        if (!(mess instanceof TextMessage)){
                return Response.status(Response.Status.BAD_REQUEST).entity("Pogresna poruka zbog tipa").build();
        }
         
         
         TextMessage resM = (TextMessage) mess;
         String re = resM.getText();
         int retu = resM.getIntProperty("status");
         if (retu != 0) 
             return Response.status(Response.Status.BAD_REQUEST).entity(re).build();
         else
             return Response.status(OK).entity("Dodali smo u korpu").build();
        
        
    }
    
    @POST
    @Path("brisiKorpu")
    public Response brisanjeIzKorpe(@FormParam("korpa")String korpa,@FormParam("kolicina")String kolicina) throws JMSException{
        
        JMSContext context = connectionFactory.createContext();
        JMSProducer producer = context.createProducer();
        JMSConsumer consumer = context.createConsumer(queue);
        
        ObjectMessage objMsg=null;
        
        Komanda komanda=new KomandaBrisanjeIzKorpe(korpa, kolicina);
        
        ObjectMessage obj=context.createObjectMessage(komanda);
        obj.setIntProperty("zahtev",10);
        obj.setIntProperty("pod", 2);
        
        producer.send(topic,obj);
        
        Message mess = consumer.receive();//odgovor
        if (!(mess instanceof TextMessage)){
                return Response.status(Response.Status.BAD_REQUEST).entity("Pogresna poruka zbog tipa").build();
        }
         
         
         TextMessage resM = (TextMessage) mess;
         String re = resM.getText();
         int retu = resM.getIntProperty("status");
         if (retu != 0) 
             return Response.status(Response.Status.BAD_REQUEST).entity(re).build();
         else
             return Response.status(OK).entity("Obrisali smo iz korpe").build();
        
    }
    
    @GET
    @Path("dohvatiKorpu/{ime}/{prezime}")
    public Response dohvatiKorpu(@PathParam("ime")String ime,@PathParam("prezime")String prezime) throws JMSException{
        JMSContext context = connectionFactory.createContext();
        JMSProducer producer = context.createProducer();
        JMSConsumer consumer = context.createConsumer(queue); 
        
        
        TextMessage msg = context.createTextMessage("zahtev");
        msg.setIntProperty("zahtev", 16);
        msg.setIntProperty("pod", 1);
        msg.setStringProperty("ime", ime);
        msg.setStringProperty("prezime", prezime);
        
        producer.send(topic, msg);
       
        Message message = consumer.receive();//odgovor
        if (!(message instanceof TextMessage)){
                return Response.status(Response.Status.BAD_REQUEST).entity("Pogresna poruka zbog tipa").build();
        }
        
        TextMessage resMsg = (TextMessage) message;
        String res = resMsg.getText();
        int ret = resMsg.getIntProperty("status");
         if (ret != 0) 
             return Response.status(Response.Status.BAD_REQUEST).entity("Nema tog korisnika").build();
         
        int flag=resMsg.getIntProperty("ima");
        
        if(flag<0){
             return Response.status(Response.Status.BAD_REQUEST).entity("Nema tog korisnika").build();
        }
        
        ObjectMessage objMsg=null;
        
        Komanda komanda=new KomandaDohvatiKorpu(flag);
        
        ObjectMessage obj=context.createObjectMessage(komanda);
        obj.setIntProperty("zahtev",16);
        obj.setIntProperty("pod", 2);
        
        producer.send(topic,obj);
       
       Message mess = consumer.receive();
       if (!(mess instanceof ObjectMessage)){
           return Response.status(Response.Status.BAD_REQUEST).entity("Pogresio si tip").build();
         }
        ObjectMessage ob = (ObjectMessage) mess;
        
        return Response.status(OK).entity(new GenericEntity<List<Korpa>>((ArrayList<Korpa>) ob.getObject()){}).build();
        
    }

}