/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package resursi;

import entities.Grad;
import entities.Korisnik;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.Resource;
import javax.jms.ConnectionFactory;
import javax.jms.JMSConsumer;
import javax.jms.JMSContext;
import javax.jms.JMSException;
import javax.jms.JMSProducer;
import javax.jms.Message;
import javax.jms.ObjectMessage;
import javax.jms.Queue;
import javax.jms.TextMessage;
import javax.jms.Topic;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.core.GenericEntity;
import javax.ws.rs.core.Response;
import static javax.ws.rs.core.Response.Status.OK;

/**
 *
 * @author Korisnik
 */
@Path("podsistem1")
public class Podsistem1 {
    
    @Resource(lookup = "connFactory1")
    ConnectionFactory connectionFactory;
    
    @Resource(lookup = "server1")
    Topic topic;
     
    @Resource(lookup = "red1")
    Queue queue;

    
    @POST
    public Response kreirajGrad(@FormParam("naziv") String naziv) throws JMSException{
        JMSContext context = connectionFactory.createContext();
        JMSProducer producer = context.createProducer();
        JMSConsumer consumer = context.createConsumer(queue);
        
        TextMessage msg = context.createTextMessage("zahtev");
        msg.setIntProperty("zahtev", 1);
        msg.setIntProperty("pod", 1);
        
        msg.setStringProperty("naziv", naziv);
        
        producer.send(topic, msg);
        
        Message message = consumer.receive();//odgovor
        if (!(message instanceof TextMessage)){
                return Response.status(Response.Status.BAD_REQUEST).entity("Pogresna poruka zbog tipa").build();
         }
         
         TextMessage resMsg = (TextMessage) message;
         String res = resMsg.getText();
         int ret = resMsg.getIntProperty("status");
         if (ret != 0) 
             return Response.status(Response.Status.BAD_REQUEST).entity(res).build();
         else
             return Response.status(OK).entity("Dodali smo grad").build();
    }

    
    @POST
    @Path("kreirajKorisnika")
    public Response kreirajKomitenta(@FormParam("ime") String ime, @FormParam("prezime") String prezime, @FormParam("adresa") String adresa, @FormParam("novac")String novac, @FormParam("grad")String naziv){
                
        
        try {
            JMSContext context = connectionFactory.createContext();
            JMSProducer producer = context.createProducer();
            JMSConsumer consumer = context.createConsumer(queue);
            
            // message
            TextMessage msg = context.createTextMessage("zahtev");
            msg.setIntProperty("zahtev", 2);
            msg.setIntProperty("pod", 1);
            
            msg.setStringProperty("ime", ime);
            msg.setStringProperty("prezime", prezime);
            msg.setStringProperty("adresa", adresa);
            msg.setStringProperty("novac", novac);
            msg.setStringProperty("grad", naziv);
            
            
            producer.send(topic, msg);
            
           
            Message message = consumer.receive();
            if (!(message instanceof TextMessage)){
                return Response.status(Response.Status.BAD_REQUEST).entity("Neodgovarajuci tip poruke!").build();
            }
            TextMessage resMsg = (TextMessage) message;
            String res = resMsg.getText();
            int ret = resMsg.getIntProperty("status");
            if (ret != 0) 
                return Response.status(Response.Status.BAD_REQUEST).entity(res).build();
           
            
        } catch (JMSException ex) {
            Logger.getLogger(Podsistem1.class.getName()).log(Level.SEVERE, null, ex);
        }
        return Response.status(OK).entity("Korisnik je uspesno kreiran!").build();
    }


    @POST
    @Path("dodajNovac")
    public Response dodavanjeNovcaKorisniku(@FormParam("korisnik")String korisnik,@FormParam("iznosUvecanja")String iznos) throws JMSException{
        JMSContext context = connectionFactory.createContext();
        JMSProducer producer = context.createProducer();
        JMSConsumer consumer = context.createConsumer(queue);
        
        TextMessage msg = context.createTextMessage("zahtev");
        msg.setIntProperty("zahtev", 3);
        msg.setIntProperty("pod", 1);
        
        msg.setStringProperty("korisnik", korisnik);
        msg.setStringProperty("iznosUvecanja", iznos);
        
        producer.send(topic, msg);
        
        Message message = consumer.receive();
        if (!(message instanceof TextMessage)){
                return Response.status(Response.Status.BAD_REQUEST).entity("Neodgovarajuci tip poruke!").build();
        }
        
        TextMessage resMsg = (TextMessage) message;
            String res = resMsg.getText();
            int ret = resMsg.getIntProperty("status");
            if (ret != 0) 
                return Response.status(Response.Status.BAD_REQUEST).entity(res).build();
           
        return Response.status(OK).entity("Plata dodata!").build();
    }
    
    @POST
    @Path("promenaAdreseIGrada")
    public Response promeniAdresuIGrad(@FormParam("idKor")String idkor,@FormParam("grad")String grad,@FormParam("adresa")String adresa) throws JMSException{
        JMSContext context = connectionFactory.createContext();
        JMSProducer producer = context.createProducer();
        JMSConsumer consumer = context.createConsumer(queue);
        
        TextMessage msg = context.createTextMessage("zahtev");
        msg.setIntProperty("zahtev", 4);
        msg.setIntProperty("pod", 1);
        
        msg.setStringProperty("korisnik", idkor);
        msg.setStringProperty("grad", grad);
        msg.setStringProperty("adresa", adresa);
        
        producer.send(topic, msg);
         
        Message message = consumer.receive();
        if (!(message instanceof TextMessage)){
                return Response.status(Response.Status.BAD_REQUEST).entity("Neodgovarajuci tip poruke!").build();
        }
        
        TextMessage resMsg = (TextMessage) message;
            String res = resMsg.getText();
            int ret = resMsg.getIntProperty("status");
            if (ret != 0) 
                return Response.status(Response.Status.BAD_REQUEST).entity(res).build();
           
        return Response.status(OK).entity("Promenjena adresa i grad").build();
    }
    
    @GET
    @Path("dohvatiGradove")
    public Response dohvatiGradove() throws JMSException{
        ObjectMessage objMsg=null;
        try {
            JMSContext context = connectionFactory.createContext();
            JMSProducer producer = context.createProducer();
            JMSConsumer consumer = context.createConsumer(queue);
            
            
            TextMessage msg = context.createTextMessage("zahtev");
            msg.setIntProperty("zahtev", 12);
            msg.setIntProperty("pod", 1);
            
            producer.send(topic, msg);
            
            
            Message mess = consumer.receive();
            if (!(mess instanceof ObjectMessage)){
                return Response.status(Response.Status.BAD_REQUEST).entity("Pogresio si tip").build();
            }
            objMsg = (ObjectMessage) mess;
             
        } catch (ClassCastException ex) {
            return Response.status(Response.Status.BAD_REQUEST).entity("Pogr obj").build();
        }
        
        return Response.status(OK).entity(new GenericEntity<List<Grad>>((ArrayList<Grad>) objMsg.getObject()){}).build();
    }
    
    @GET
    @Path("dohvatiKorisnike")
    public Response dohvatiKorisnike() throws JMSException{
        ObjectMessage objMsg=null;
        
            JMSContext context = connectionFactory.createContext();
            JMSProducer producer = context.createProducer();
            JMSConsumer consumer = context.createConsumer(queue);
            
       
            TextMessage msg = context.createTextMessage("zahtev");
            msg.setIntProperty("zahtev", 13);
            msg.setIntProperty("pod", 1);
            
            producer.send(topic, msg);
            
          
            Message mess = consumer.receive();
            if (!(mess instanceof ObjectMessage)){
                return Response.status(Response.Status.BAD_REQUEST).entity("Pogresio si tip").build();
            }
            objMsg = (ObjectMessage) mess;
             
       
        
        return Response.status(OK).entity(new GenericEntity<List<Korisnik>>((ArrayList<Korisnik>) objMsg.getObject()){}).build();
    }
    
}
