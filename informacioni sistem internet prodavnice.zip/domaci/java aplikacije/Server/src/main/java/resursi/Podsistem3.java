/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package resursi;

import entities.Kategorija;
import entities.Korpa;
import entities.Kupoprodaja;
import entities.Narudbina;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.Resource;
import javax.jms.ConnectionFactory;
import javax.jms.JMSConsumer;
import javax.jms.JMSContext;
import javax.jms.JMSException;
import javax.jms.JMSProducer;
import javax.jms.Message;
import javax.jms.ObjectMessage;
import javax.jms.Queue;
import javax.jms.TextMessage;
import javax.jms.Topic;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.GenericEntity;
import javax.ws.rs.core.Response;
import static javax.ws.rs.core.Response.Status.OK;
import komanda.Komanda;
import komanda.KomandaDohvatiKorpu;
import komanda.KomandaDohvatiNarudbine;
import komanda.KomandaDohvatiNarudbineKorisnika;
import komanda.KomandaDohvatiTransakcije;
import komanda.KomandaObrisiZaKorisnikaKorpu;
import komanda.KomandaPraviTransakciju;

/**
 *
 * @author Korisnik
 */
@Path("podsistem3")
public class Podsistem3 {
    @Resource(lookup = "connFactory1")
    ConnectionFactory connectionFactory;
    
    @Resource(lookup = "server1")
    Topic topic;
     
    @Resource(lookup = "red1")
    Queue queue;
    
    @POST
    @Path("napraviTransakciju")
    public Response transakcija(@FormParam("kupac")String idKupac) throws JMSException{
        
        
        JMSContext context = connectionFactory.createContext();
        JMSProducer producer = context.createProducer();
        JMSConsumer consumer = context.createConsumer(queue);
        
        
        //provera da li postoji taj kupac i dohvatanje grada i adrese kupca
        TextMessage msg = context.createTextMessage("zahtev");
        msg.setIntProperty("zahtev", 11);
        msg.setIntProperty("pod", 1);
        msg.setStringProperty("kupac", idKupac);
        producer.send(topic, msg);
        
        Message message = consumer.receive();//odgovor
        if (!(message instanceof TextMessage)){
                return Response.status(Response.Status.BAD_REQUEST).entity("Pogresna poruka zbog tipa").build();
         }
         
         TextMessage resMsg = (TextMessage) message;
         String res = resMsg.getText();
         int ret = resMsg.getIntProperty("status");
         if (ret != 0) 
             return Response.status(Response.Status.BAD_REQUEST).entity(res).build();
        
        //dohvatanje svih narudbina iz korpe u podsistemu 2
        String grad=resMsg.getStringProperty("grad");
        String adresa=resMsg.getStringProperty("adresa");
        
        ObjectMessage objMsg=null;
        
        Komanda komanda1=new KomandaDohvatiKorpu(Integer.parseInt(idKupac));
        
       ObjectMessage obj=context.createObjectMessage(komanda1);
       obj.setIntProperty("zahtev",16);
       obj.setIntProperty("pod", 2);
       obj.setStringProperty("grad", grad);//ovo treba dole
       obj.setStringProperty("adresa", adresa);
       
       producer.send(topic,obj);
       
       Message mess = consumer.receive();
       if (!(mess instanceof ObjectMessage)){
           return Response.status(Response.Status.BAD_REQUEST).entity("Pogresio si tip").build();
        }
       
        objMsg = (ObjectMessage) mess;
        
        ArrayList<Korpa> korpa=(ArrayList<Korpa>)objMsg.getObject();
        
        //Integer prodavac=obj.getIntProperty("prodavac");
        
        
        //postavljanje stavki iz korpe u tabelu stavka u podsistemu 3
                
                //za sve te narudbine kreiramo jednu transakciju  kupcu umanjujemo iznos, prodavcu povecavamo za svaku stavku u korpi
        
        Komanda komanda3=new KomandaPraviTransakciju(korpa,Integer.parseInt(idKupac),grad,adresa);
        obj=context.createObjectMessage(komanda3);
        obj.setIntProperty("zahtev",16);
        obj.setIntProperty("pod", 3);
        //obj.setStringProperty("grad", grad);
        //obj.setStringProperty("adresa", adresa);
        //obj.setIntProperty("prodavac", prodavac);
        obj.setIntProperty("kupac",Integer.parseInt(idKupac));
        
        producer.send(topic,obj);
       
        mess = consumer.receive();
        if (!(mess instanceof TextMessage)){
           return Response.status(Response.Status.BAD_REQUEST).entity("Pogresio si tip").build();
        }
        
        //promena stanja na racunima kupaca i prodavaca
        //ovu funcionalnost dodajme podsistemu 1
        
        StringBuffer buffer=new StringBuffer();
        for(Korpa k:korpa){
            buffer.append(k.getIdartikal().getKorisnik());
            buffer.append("-");
            buffer.append(k.getUkupnaCena());
            buffer.append(" ");
        }
        
            msg = context.createTextMessage("zahtev");
            msg.setIntProperty("zahtev", 111);
            msg.setIntProperty("pod", 1);
            msg.setStringProperty("bafer",buffer.toString());
            msg.setStringProperty("kupac",idKupac);
            producer.send(topic, msg);
            
          
            mess = consumer.receive();
            /*if (!(mess instanceof TextMessage)){
                return Response.status(Response.Status.BAD_REQUEST).entity("Pogresio si tip").build();
            }*/
        
            
        //brisanje svih narudbina iz korpe u podsistemu 2 za tog kupca
       Komanda komanda2=new KomandaObrisiZaKorisnikaKorpu(Integer.parseInt(idKupac));
       obj=context.createObjectMessage(komanda2);
       obj.setIntProperty("zahtev",16);
       obj.setIntProperty("pod", 2);
       producer.send(topic,obj);
       
       mess = consumer.receive();
       if (!(mess instanceof TextMessage)){
           return Response.status(Response.Status.BAD_REQUEST).entity("Pogresio si tip").build();
        }
        return Response.status(OK).entity("Cestitamo uspesno ste obavili transakciju").build();
    }
    
    
    
    @GET
    @Path("dohvatiNarudbinuKorisnika/{idKor}")
    public Response dohvatiNarudbineKorisnika(@PathParam("idKor")String idKor) throws JMSException{
        
        
        ObjectMessage objMsg=null;
        
        JMSContext context = connectionFactory.createContext();
        JMSProducer producer = context.createProducer();
        JMSConsumer consumer = context.createConsumer(queue);
        
        
        Komanda komanda=new KomandaDohvatiNarudbineKorisnika(idKor);
        
        ObjectMessage obj=context.createObjectMessage(komanda);
        obj.setIntProperty("zahtev",17);
        obj.setIntProperty("pod", 3);
        
        producer.send(topic,obj);
        
        
        Message mess = consumer.receive();
       if (!(mess instanceof ObjectMessage)){
           return Response.status(Response.Status.BAD_REQUEST).entity("Pogresio si tip").build();
         }
        objMsg = (ObjectMessage) mess;
        
        return Response.status(OK).entity(new GenericEntity<List<Narudbina>>((ArrayList<Narudbina>) objMsg.getObject()){}).build();

    }
    
    
    
    
    @GET
    @Path("dohvatiNarudbine")
    public Response dohvatiNarudbine() throws JMSException{
        ObjectMessage objMsg=null;
        
        JMSContext context = connectionFactory.createContext();
        JMSProducer producer = context.createProducer();
        JMSConsumer consumer = context.createConsumer(queue);
        
        Komanda komanda=new KomandaDohvatiNarudbine();
        
        ObjectMessage obj=context.createObjectMessage(komanda);
        obj.setIntProperty("zahtev",18);
        obj.setIntProperty("pod", 3);
        
        producer.send(topic,obj);
        
         Message mess = consumer.receive();
       if (!(mess instanceof ObjectMessage)){
           return Response.status(Response.Status.BAD_REQUEST).entity("Pogresio si tip").build();
         }
        objMsg = (ObjectMessage) mess;
        
        return Response.status(OK).entity(new GenericEntity<List<Narudbina>>((ArrayList<Narudbina>) objMsg.getObject()){}).build();
    }
    
    
    @GET
    @Path("dohvatiTransakcije")
    public Response dohvatiTransakcije() throws JMSException{
        ObjectMessage objMsg=null;
        
        JMSContext context = connectionFactory.createContext();
        JMSProducer producer = context.createProducer();
        JMSConsumer consumer = context.createConsumer(queue);
        
        Komanda komanda=new KomandaDohvatiTransakcije();
        
        ObjectMessage obj=context.createObjectMessage(komanda);
        obj.setIntProperty("zahtev",19);
        obj.setIntProperty("pod", 3);
        
        producer.send(topic,obj);
        
        Message mess = consumer.receive();
       if (!(mess instanceof ObjectMessage)){
           return Response.status(Response.Status.BAD_REQUEST).entity("Pogresio si tip").build();
         }
        objMsg = (ObjectMessage) mess;
        
        return Response.status(OK).entity(new GenericEntity<List<Kupoprodaja>>((ArrayList<Kupoprodaja>) objMsg.getObject()){}).build();
        
    }
}
