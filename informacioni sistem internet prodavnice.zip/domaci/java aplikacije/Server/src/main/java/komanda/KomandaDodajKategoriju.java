/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package komanda;

import entities.Kategorija;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.jms.JMSContext;
import javax.jms.JMSException;
import javax.jms.TextMessage;
import javax.persistence.EntityExistsException;
import javax.persistence.EntityManager;

/**
 *
 * @author Korisnik
 */
public class KomandaDodajKategoriju extends Komanda {

    private String kategorija;
    private String nadKategorija;
    
    
    public KomandaDodajKategoriju(){}
    public KomandaDodajKategoriju(String kategorija,String nadKategorija){
        this.kategorija=kategorija;
        this.nadKategorija=nadKategorija;
    }
    @Override
    public TextMessage izvrsi() {
        TextMessage msg = null;
        try {
            
            
            Kategorija kat=new Kategorija();
            kat.setNaziv(this.kategorija);
            if(!nadKategorija.equals("nema"))
                kat.setPodkategorija(Integer.parseInt(this.nadKategorija));
            
            List<Kategorija> ka = em.createNamedQuery("Kategorija.findByNaziv", Kategorija.class).setParameter("naziv", kategorija).getResultList();
            Kategorija k = (ka.isEmpty()? null : ka.get(0));
            
            String txt = "Kategorija dodata!";
            int status = 0;
            if(k!=null){
                txt="Vec postoji";
                status=-1;
            }else{
                try
                {
                    em.getTransaction().begin();
                    em.persist(kat);
                    em.getTransaction().commit();
                    status=0;
                }
                catch(EntityExistsException e)
                {
                    txt = "Kategorija vec postoji!";
                    status = -1;
                }
                finally
                {
                    if (em.getTransaction().isActive())
                        em.getTransaction().rollback();
                }
        
            }
            
            msg = context.createTextMessage(txt);
            msg.setIntProperty("status", status);
        } catch (JMSException ex) {
            Logger.getLogger(KomandaDodajKategoriju.class.getName()).log(Level.SEVERE, null, ex);
        }
        return msg;
    }
    
    
    
}
