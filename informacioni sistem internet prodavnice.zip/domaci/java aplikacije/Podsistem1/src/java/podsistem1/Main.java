/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package podsistem1;

import entities.Grad;
import entities.Korisnik;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.Resource;
import javax.jms.ConnectionFactory;
import javax.jms.JMSConsumer;
import javax.jms.JMSContext;
import javax.jms.JMSException;
import javax.jms.JMSProducer;
import javax.jms.Message;
import javax.jms.Queue;
import javax.jms.TextMessage;
import javax.jms.Topic;
import javax.persistence.EntityExistsException;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.PersistenceContext;
import javax.ws.rs.ext.Provider;

/**
 *
 * @author Korisnik
 */

public class Main {

    /**
     * @param args the command line arguments
     */
    
    static EntityManagerFactory emf = Persistence.createEntityManagerFactory("Podsistem1PU");
    static EntityManager em = emf.createEntityManager();
    

    @Resource(lookup = "connFactory1")
    static ConnectionFactory connFactory;
    
    @Resource(lookup="server1")
    static Topic topic;
    
    @Resource(lookup="red1")
    static Queue queue;
    
    
    static JMSContext context;
    static JMSConsumer consumer;
    static JMSProducer producer;

    
    
    private TextMessage kreirajGrad(String naziv){
        TextMessage msg = null;
        try {
            Grad grad = new Grad();
            grad.setNaziv(naziv);
           
            
            List<Grad> gradovi = em.createNamedQuery("Grad.findByNaziv", Grad.class).setParameter("naziv", naziv).getResultList();
            Grad g = (gradovi.isEmpty()? null : gradovi.get(0));
            
            String txt = "Grad dodat!";
            int status = 0;
            if (g != null){
                txt = "Vec postoji!";
                status = -1;
            }
            else {
                try
                {
                    em.getTransaction().begin();
                    em.persist(grad);
                    em.getTransaction().commit();
                }
                catch(EntityExistsException e)
                {
                    txt = "Grad vec postoji!";
                    status = -1;
                }
                finally
                {
                     if (em.getTransaction().isActive())
                        em.getTransaction().rollback();
                }
                
            }
            msg = context.createTextMessage(txt);
            msg.setIntProperty("status", status);
        } catch (JMSException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        }
        return msg;
    }

     
    
    private void obrada() {
        
        
        
        while(true){
           try {
            System.out.println("Podsistem1...");
            
            TextMessage msg = (TextMessage) consumer.receive();
            
            int zahtev = msg.getIntProperty("zahtev");
                
            Message response = null;
            
            if(zahtev==1){
                String naziv = msg.getStringProperty("naziv");
                response=kreirajGrad(naziv);
            }else if(zahtev==2){
                String ime = msg.getStringProperty("ime");
                String prezime = msg.getStringProperty("prezime");
                String adresa = msg.getStringProperty("adresa");
                String novac = msg.getStringProperty("novac");
                String nazivGrada = msg.getStringProperty("grad");
                response=dodajKorisnika(ime,prezime,adresa,novac,nazivGrada);
            }else if(zahtev==3){
                String idKor=msg.getStringProperty("korisnik");
                String novac=msg.getStringProperty("iznosUvecanja");
                response=dodajNovac(idKor,novac);
            }else if(zahtev==4){
                String idKor=msg.getStringProperty("korisnik");
                String grad=msg.getStringProperty("grad");
                String adresa=msg.getStringProperty("adresa");
                response=promeniAdresuIGrad(idKor,grad,adresa);
            }else if(zahtev==12){//konacno proradilo ! greska je bila u inverznim poljima!
                ArrayList<Grad> gradovi=new ArrayList<>();
                List<Grad> gr=em.createNamedQuery("Grad.findAll", Grad.class).getResultList();
                for(Grad g:gr){
                    gradovi.add(g);
                }
                response=context.createObjectMessage(gradovi);
            }else if(zahtev==13){
                ArrayList<Korisnik> korisnici=new ArrayList<>();
                List<Korisnik> kor=em.createNamedQuery("Korisnik.findAll", Korisnik.class).getResultList();
                for(Korisnik k:kor){
                     korisnici.add(k);
                }
                response=context.createObjectMessage(korisnici);
            }else if(zahtev==15){
                String ime=msg.getStringProperty("ime");
                String prezime=msg.getStringProperty("prezime");
                List<Korisnik> kor1=em.createNamedQuery("Korisnik.findByIme",Korisnik.class).setParameter("ime", ime).getResultList();
                List<Korisnik> kor2=em.createNamedQuery("Korisnik.findByPrezime",Korisnik.class).setParameter("prezime", prezime).getResultList();
                List<Korisnik> kor3 = em.createQuery("SELECT k from Korisnik k where k.ime = :ime and k.prezime = :prezime", Korisnik.class).setParameter("ime",ime).setParameter("prezime", prezime).getResultList();
                if(!kor1.isEmpty() && !kor2.isEmpty() && !kor3.isEmpty()){
                    
                    response=context.createTextMessage("Ima");
                    response.setIntProperty("korisnik", kor3.get(0).getIdkorisnik());
                    response.setIntProperty("status", 0);
                }else{
                response=context.createTextMessage("Nema");
                response.setIntProperty("korisnik", -1);
                response.setIntProperty("status", -1);
                }
                
            }else if(zahtev==6){
                String korisnik=msg.getStringProperty("korisnik");
                List<Korisnik> korisnici=em.createNamedQuery("Korisnik.findByIdkorisnik", Korisnik.class).setParameter("idkorisnik",Integer.parseInt(korisnik)).getResultList();
                if(korisnici.isEmpty()){
                    response=context.createTextMessage("Nema tog korisnika");
                    response.setIntProperty("ima", -1);
                    response.setIntProperty("status", -1);
                }else{
                    response=context.createTextMessage("Ima tog korisnika");
                    response.setIntProperty("ima",1);
                    response.setIntProperty("status", 0);
                }
            }else if(zahtev==9){
                 String korisnik=msg.getStringProperty("idkori");
                 List<Korisnik> korisnici=em.createNamedQuery("Korisnik.findByIdkorisnik", Korisnik.class).setParameter("idkorisnik",Integer.parseInt(korisnik)).getResultList();
                 if(korisnici.isEmpty()){
                    response=context.createTextMessage("Nema tog korisnika");
                    response.setIntProperty("ima", -1);
                    response.setIntProperty("status", -1);
                }else{
                    response=context.createTextMessage("Ima tog korisnika");
                    response.setIntProperty("ima",1);
                    response.setIntProperty("status", 0);
                }
            }else if(zahtev==16){
                String ime=msg.getStringProperty("ime");
                String prezime=msg.getStringProperty("prezime");
                List<Korisnik> kor3 = em.createQuery("SELECT k from Korisnik k where k.ime = :ime and k.prezime = :prezime", Korisnik.class).setParameter("ime",ime).setParameter("prezime", prezime).getResultList();
                if(!kor3.isEmpty()){
                    response=context.createTextMessage("Ima tog korisnika");
                     response.setIntProperty("ima",kor3.get(0).getIdkorisnik());
                    response.setIntProperty("status", 0);
                }else{
                    response=context.createTextMessage("Nema tog korisnika");
                    response.setIntProperty("ima", -1);
                    response.setIntProperty("status", -1);
                    
                }
            
            }else if(zahtev==11){
               String idkorisnika=msg.getStringProperty("kupac");
               List<Korisnik> korisnici=em.createNamedQuery("Korisnik.findByIdkorisnik", Korisnik.class).setParameter("idkorisnik",Integer.parseInt(idkorisnika)).getResultList();
               if(!korisnici.isEmpty()){
                   response=context.createTextMessage("Ima tog korisnika");
                   response.setIntProperty("status", 0);
                   response.setStringProperty("adresa", korisnici.get(0).getAdresa());
                   response.setStringProperty("grad", korisnici.get(0).getIdgrad().getNaziv());
               }else{
                   response=context.createTextMessage("Nema tog korisnika");
                   response.setIntProperty("status", -1);
               }
            }else if(zahtev==111){
                String txt="Sve u redu";
                int status=0;
                int zaPlacanje=0;
                String[] str=msg.getStringProperty("bafer").split(" ");
                for(String st:str){
                    String[] p1=st.split("-");
                    Integer korisnik=Integer.parseInt(p1[0]);
                    Integer cena=Integer.parseInt(p1[1]);
                    zaPlacanje+=cena;
                    List<Korisnik> kor=em.createNamedQuery("Korisnik.findByIdkorisnik", Korisnik.class).setParameter("idkorisnik", korisnik).getResultList();
                    if(!kor.isEmpty()){
                        try
                        {
                            em.getTransaction().begin();
                            kor.get(0).setNovac(kor.get(0).getNovac()+cena);
                            em.getTransaction().commit();
                        }
                        catch(EntityExistsException e)
                        {
                            txt = "Korisnik nije u redu postoji!";
                            status = -1;
                        }
                        finally
                        {
                            if (em.getTransaction().isActive())
                                em.getTransaction().rollback();
                            }
                         }
                    
                }
                
                String kupac=msg.getStringProperty("kupac");
                Integer idKup=Integer.parseInt(kupac);
                List<Korisnik> kor=em.createNamedQuery("Korisnik.findByIdkorisnik", Korisnik.class).setParameter("idkorisnik", idKup).getResultList();
                if(!kor.isEmpty()){
                     try
                        {
                            em.getTransaction().begin();
                            kor.get(0).setNovac(kor.get(0).getNovac()-zaPlacanje);
                            em.getTransaction().commit();
                        }
                        catch(EntityExistsException e)
                        {
                            txt = "Korisnik nije u redu postoji!";
                            status = -1;
                        }
                        finally
                        {
                            if (em.getTransaction().isActive())
                                em.getTransaction().rollback();
                            }
                 }
 
                response=context.createTextMessage(txt);
                response.setIntProperty("status",status);
            
                
            }
            
                
                
            producer.send(queue,response);
            } catch (JMSException ex) {
                Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
            }
            
            
            
        }
        
        
    }

    
    public static void main(String[] args) {

        try{
        String msgSelector = "pod=1";
        context = connFactory.createContext();
        context.setClientID("1");
        consumer = context.createDurableConsumer(topic, "sub1", msgSelector, false);
        producer = context.createProducer();
        
        
        Main podsistem1=new Main();
        podsistem1.obrada();
        //podsistem1.kreirajGrad("Kooovvin");
        }catch(Throwable t){
            t.printStackTrace();
        }finally{
        em.close();
        }
    }

    private TextMessage dodajKorisnika(String ime, String prezime, String adresa, String novac,String grad) {
    
        TextMessage msg = null;
        try {
            Korisnik korisnik = new Korisnik();
            korisnik.setIme(ime);
            korisnik.setPrezime(prezime);
            korisnik.setAdresa(adresa);
            korisnik.setNovac(Integer.parseInt(novac));
            
            
            List<Grad> gradovi = em.createNamedQuery("Grad.findByNaziv", Grad.class).setParameter("naziv", grad).getResultList();
            Grad g = (gradovi.isEmpty()? null : gradovi.get(0));
            
            
            
            String txt = "Korisnik uspesno kreiran!";
            int status = 0;
            if (g == null){
                txt = "Zadato mesto ne postoji!";
                status = -1;
            }
            else {
                
                korisnik.setIdgrad(g);
                
                try
                {
                    em.getTransaction().begin();
                    em.persist(korisnik);
                    em.getTransaction().commit();
                }
                catch(EntityExistsException e)
                {
                    txt = "Korisnik vec postoji!";
                    status = -1;
                }
                finally
                {
                     if (em.getTransaction().isActive())
                        em.getTransaction().rollback();
                }
                
            }
            msg = context.createTextMessage(txt);
            msg.setIntProperty("status", status);
        } catch (JMSException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        }
        return msg;
    }

    private TextMessage dodajNovac(String idKor, String novac) throws JMSException {
    
        TextMessage msg = null;
        String porukica;
        int status = 0;
        
        List<Korisnik> korisnici=em.createNamedQuery("Korisnik.findByIdkorisnik", Korisnik.class).setParameter("idkorisnik",Integer.parseInt(idKor)).getResultList();
        if(korisnici.isEmpty()){
            porukica="Ne postoji taj korisnik";
            status=-1;
        }else{
            porukica="Korisnik postoji";
        
        
        Korisnik korisnik=korisnici.get(0);
        
        Integer suma=korisnik.getNovac();
        
        try
        {
            em.getTransaction().begin();
            korisnik.setNovac(suma+Integer.parseInt(novac));
            em.getTransaction().commit();
        }
        catch(EntityExistsException e)
        {
            porukica +="i nije dodat novac";
            status = -1;
        }
        finally
        {
            if (em.getTransaction().isActive())
                em.getTransaction().rollback();
        }
        
        porukica+="i novac je dodat.";
        }
        msg = context.createTextMessage(porukica);
        msg.setIntProperty("status", status);
        
        return msg;
        
    }

    private TextMessage promeniAdresuIGrad(String idKor, String grad, String adresa) throws JMSException {
        TextMessage msg = null;
        String porukica=null;
        int status = 0;
        
        List<Korisnik> korisnici=em.createNamedQuery("Korisnik.findByIdkorisnik", Korisnik.class).setParameter("idkorisnik",Integer.parseInt(idKor)).getResultList();
        if(korisnici.isEmpty()){
            porukica="Ne postoji taj korisnik";
            status=-1;
        }else{
            Korisnik korisnik=korisnici.get(0);
            List<Grad> gradovi = em.createNamedQuery("Grad.findByNaziv", Grad.class).setParameter("naziv", grad).getResultList();
            Grad g = (gradovi.isEmpty()? null : gradovi.get(0));
            if(g==null){
                porukica="Ne postoji taj grad";
                status=-1;
            }else{
                try
                {
                        em.getTransaction().begin();
                        korisnik.setIdgrad(g);
                        korisnik.setAdresa(adresa);
                        em.getTransaction().commit();
                }
                catch(EntityExistsException e)
                {
                         porukica +="i nije promenjeno";
                         status = -1;
                }
                finally
                {
                    if (em.getTransaction().isActive())
                        em.getTransaction().rollback();
                }
                
                porukica+="i promenjeno je sve sto treba";
            }
            
        }
        
        
        msg = context.createTextMessage(porukica);
        msg.setIntProperty("status", status);
        return msg;
        
        
    }
    
    
}
