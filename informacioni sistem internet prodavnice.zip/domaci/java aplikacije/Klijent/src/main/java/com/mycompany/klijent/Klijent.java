/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.klijent;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.StringReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.CharacterData;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

/**
 *
 * @author Korisnik
 */
public class Klijent {

    BufferedReader inputStream = new BufferedReader(new InputStreamReader(System.in));
    public void obrada() throws IOException{
        int zahtev=50;
        while(true){
            System.out.println("Unesite broj zahteva:");
            
            String ulaz=null;
            try {
                ulaz = inputStream.readLine();
            } catch (IOException ex) {
                Logger.getLogger(Klijent.class.getName()).log(Level.SEVERE, null, ex);
            }
            zahtev=Integer.parseInt(ulaz);
            
            if(zahtev==0){ break;}
            else if(zahtev==1){
                System.out.println("Unesite naziv grada:");
                String naziv=inputStream.readLine();
                kreirajGrad(naziv);
            }else if(zahtev==2){
                System.out.println("Unsite ime:");
                String ime=inputStream.readLine();
                System.out.println("Unesite prezime:");
                String prezime=inputStream.readLine();
                System.out.println("Unesite adresu korisnika:");
                String adresa=inputStream.readLine();
                System.out.println("Unesite novac na racunu:");
                String novac=inputStream.readLine();
                System.out.println("Unesite naziv grada:");
                String grad=inputStream.readLine();
                
                krirajKorisnika(ime,prezime,adresa,novac,grad);
            }else if(zahtev==3){
                System.out.println("Unesite id korisnika kome uvecavamo iznos novca:");
                String idKorisnika=inputStream.readLine();
                System.out.println("Unesite iznos za koliko uvecavate:");
                String iznos=inputStream.readLine();
                dodajNovacKorisniku(idKorisnika,iznos);
            }else if(zahtev==4){
                System.out.println("Unesite id korisnika kome menjate adresu i grad:");
                String idKor=inputStream.readLine();
                System.out.println("Unesite grad:");
                String grad=inputStream.readLine();
                System.out.println("Unesite adresu korisnika:");
                String adresa=inputStream.readLine();
                promeniAdresuIGrad(idKor,grad,adresa);
            }else if(zahtev==5){
                System.out.println("Unesite naziv kategorije");
                String kategorija=inputStream.readLine();
                System.out.println("Unesite id nadkategorije ako postoji(ako ne postoji unesite nema):");
                String nadKategorija=inputStream.readLine();
                dodajKategoriju(kategorija,nadKategorija);
            }else if(zahtev==6){
                System.out.println("Unesite naziv artikla");
                String naziv=inputStream.readLine();
                System.out.println("Unesite opis proizvoda:");
                String opis=inputStream.readLine();
                System.out.println("Unesite cenu proizvoda:");
                String cena=inputStream.readLine();
                System.out.println("Unesite popust za proizvod(ako ga nema upisite 0):");
                String popust=inputStream.readLine();
                System.out.println("Unesite id prodavca:");
                String prodavac=inputStream.readLine();
                System.out.println("Unesite id kategorije kome pripada dati proiyvod:");
                String kategorija=inputStream.readLine();
                napraviArtikl(naziv,opis,cena,popust,prodavac,kategorija);
            }else if(zahtev==7){
                System.out.println("Unesite id artikla kome menjamo cenu:");
                String idartikla=inputStream.readLine();
                System.out.println("Unesite novu cenu:");
                String cena=inputStream.readLine();
                promeniCenuArtikla(idartikla,cena);
            }else if(zahtev==8){
                System.out.println("Unesite id artikla kome postavljamo popust:");
                String idartikla=inputStream.readLine();
                System.out.println("Unesite popust za artikal:");
                String popust=inputStream.readLine();
                dodajPopust(idartikla,popust);
            }else if(zahtev==9){
                System.out.println("Unesite id korisnika koji dodaje u korpu:");
                String idkor=inputStream.readLine();
                System.out.println("Unesite id artikla koji dodajete u korpu:");
                String idartikla=inputStream.readLine();
                System.out.println("Unesite kolicinu koju dodajete:");
                String kolicina=inputStream.readLine();
                dodajUKorpu(idkor,idartikla,kolicina);
            }else if(zahtev==10){
                System.out.println("Unesite id korpe iz koje se brise:");
                String korpa=inputStream.readLine();
                System.out.println("Unesite kolicinu koju brisete:");
                String kolicina=inputStream.readLine();
                obrisiIzKorpe(korpa,kolicina);
            }else if(zahtev==11){
                System.out.println("Unesite id korisnika za koji se vrsi kupovina:");
                String korisnik=inputStream.readLine();
                transakcija(korisnik);
            }else if(zahtev==12){
                dohvatiSveGradove();
            }else if(zahtev==13){
                dohvatiSveKorisnike();
            }
            else if(zahtev==14){
                dohvatiSveKategorije();
            }else if(zahtev==15){
                System.out.println("Unesite Vase ime:");
                String ime=inputStream.readLine();
                System.out.println("Unesite Vase prezime:");
                String prezime=inputStream.readLine();
                dohvatiSveArtikleKorisnika(ime,prezime);
            }else if(zahtev==16){
                System.out.println("Unesite ime:");
                String ime=inputStream.readLine();
                System.out.println("Unesite prezime:");
                String prezime=inputStream.readLine();
                dohvatiSadrzajKorpeKorisnika(ime,prezime);
                        
            }else if(zahtev==17){
                System.out.println("Unesite Vas id u tabeli Korisnik:");
                String idKorisnika=inputStream.readLine();
                dohvatiSveNarudbineKorisnika(idKorisnika);
            }else if(zahtev==18){
                dohvatiSveNarudbine();
            }else if(zahtev==19){
                dohvatiSveTransakcije();
            }else{
                System.out.println("Pogresili ste broj...");
            }
            
            
            
        }
    }
    
    
    public void ispisMenija(){
        System.out.println("1.Kreiraj grad.");
        System.out.println("2.Kreiraj korisnika");
        System.out.println("3.Dodaj novac korisniku");
        System.out.println("4. Promeni adresu i grad korisnika");
        System.out.println("5.Kreiraj kategoriju");
        System.out.println("6.Kreiraj artikal");
        System.out.println("7.Promeni cenu artikla");
        System.out.println("8.Postavi popust za artikal");
        System.out.println("9.Dodaj artikal u korpu u odredjenoj kolicini");
        System.out.println("10. Izbrisi artikal u odredjenoj kolicini iz korpe");
        System.out.println("11.Placanje, pravljenje narudbina, dodavanje stavki, kriranje transakcije");
        System.out.println("12.Dohvati sve gradove");
        System.out.println("13.Dohvati sve korisnike");
        System.out.println("14.Dohvati sve kategorije");
        System.out.println("15.Dohvati sve artikle korisnika");
        System.out.println("16.Dohvati korpu od korisnika");
        System.out.println("17.Dohvati sve narudbine korisnika");
        System.out.println("18.Dohvati sve narudbine");
        System.out.println("19.Dohvati sve transakcije");   
        System.out.println("Unesite 0. za kraj");
        
        
    }
    public static void main(String[] args) throws IOException {
        System.out.println("Hello World!");
        Klijent  klijent=new Klijent();
        klijent.ispisMenija();
        while(true){
        try{
        klijent.obrada();
        }catch(Throwable t){
            klijent.obrada();
        }
        }
    }
    
    public void kreirajGrad(String naziv){
        try {
            String adresa="http://localhost:8080/Server/resources/podsistem1/";
            int response=0;
            
            URL url=new URL(adresa);
            
            HttpURLConnection http = (HttpURLConnection) url.openConnection();
            
            http.setRequestMethod("POST");
            http.setDoOutput(true);
            
            String query="naziv="+naziv;
            
            OutputStream output = http.getOutputStream();
            output.write(query.getBytes());
            output.flush();
            
            response=http.getResponseCode();
            
            System.out.println("Status izvrenja:"+response);
            
            System.out.println("Odgovor:");
            
            String str=null;
            BufferedReader in = new BufferedReader(new InputStreamReader(http.getInputStream()));
            while ((str = in.readLine()) != null){ 
                 System.out.println(str);
            }
                in.close();
            
        } catch (MalformedURLException ex) {
            Logger.getLogger(Klijent.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Klijent.class.getName()).log(Level.SEVERE, null, ex);
        }   
        
    }

    private void krirajKorisnika(String ime, String prezime, String adresa, String novac, String grad) {
    
        try {
            String adresaURL="http://localhost:8080/Server/resources/podsistem1/kreirajKorisnika";
            int response=0;
            
            URL url=new URL(adresaURL);
            
            HttpURLConnection http = (HttpURLConnection) url.openConnection();
            
            http.setRequestMethod("POST");
            http.setDoOutput(true);
            
            String query="ime="+ime+"&prezime="+prezime+"&adresa="+adresa+"&novac="+novac+"&grad="+grad;
            
            
            OutputStream output = http.getOutputStream();
            output.write(query.getBytes());
            output.flush();
            
            response=http.getResponseCode();
            
            System.out.println("Status izvrenja:"+response);
            
            System.out.println("Odgovor:");
            
            String str=null;
            BufferedReader in = new BufferedReader(new InputStreamReader(http.getInputStream()));
            while ((str = in.readLine()) != null) {
                System.out.println(str);
            }
            in.close();
            
        } catch (MalformedURLException ex) {
            Logger.getLogger(Klijent.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Klijent.class.getName()).log(Level.SEVERE, null, ex);
        }   
    
    
    }

    private void dodajNovacKorisniku(String idKorisnika, String iznos) {
    
    
        try {
            String adresaURL="http://localhost:8080/Server/resources/podsistem1/dodajNovac";
            int response=0;
            
            URL url=new URL(adresaURL);
            
            HttpURLConnection http = (HttpURLConnection) url.openConnection();
            
            http.setRequestMethod("POST");
            http.setDoOutput(true);
            
            String query="korisnik="+idKorisnika+"&iznosUvecanja="+iznos;
            
            
            OutputStream output = http.getOutputStream();
            output.write(query.getBytes());
            output.flush();
            
            response=http.getResponseCode();
            
            System.out.println("Status izvrenja:"+response);
            
            System.out.println("Odgovor:");
            
            String str=null;
            BufferedReader in = new BufferedReader(new InputStreamReader(http.getInputStream()));
            while ((str = in.readLine()) != null){ 
                System.out.println(str);
            }
            in.close();
            
        } catch (MalformedURLException ex) {
            Logger.getLogger(Klijent.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Klijent.class.getName()).log(Level.SEVERE, null, ex);
        }
    
    }

    private void promeniAdresuIGrad(String idKor, String grad, String adresa) {
    
        try {
            String adresaURL="http://localhost:8080/Server/resources/podsistem1/promenaAdreseIGrada";
            int response=0;
            
            URL url=new URL(adresaURL);
            
            HttpURLConnection http = (HttpURLConnection) url.openConnection();
            
            http.setRequestMethod("POST");
            http.setDoOutput(true);
            
            String query="idKor="+idKor+"&grad="+grad+"&adresa="+adresa;
            
            
            OutputStream output = http.getOutputStream();
            output.write(query.getBytes());
            output.flush();
            
            response=http.getResponseCode();
            
            System.out.println("Status izvrenja:"+response);
            
            System.out.println("Odgovor:");
            
            String str=null;
            BufferedReader in = new BufferedReader(new InputStreamReader(http.getInputStream()));
            while ((str = in.readLine()) != null){ 
                System.out.println(str);
            }
            in.close();
            
        } catch (MalformedURLException ex) {
            Logger.getLogger(Klijent.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Klijent.class.getName()).log(Level.SEVERE, null, ex);
        }

    
    }

    private void dodajKategoriju(String kategorija, String nadKategorija) {
    
        try {
            String adresaURL="http://localhost:8080/Server/resources/podsistem2/kreirajKategoriju";
            int response=0;
            
            URL url=new URL(adresaURL);
            
            HttpURLConnection http = (HttpURLConnection) url.openConnection();
            
            http.setRequestMethod("POST");
            http.setDoOutput(true);
            
            String query="kategorija="+kategorija+"&nadKategorija="+nadKategorija;
            
            
            OutputStream output = http.getOutputStream();
            output.write(query.getBytes());
            output.flush();
            
            response=http.getResponseCode();
            
            System.out.println("Status izvrenja:"+response);
            
            System.out.println("Odgovor:");
            
            String str=null;
            BufferedReader in = new BufferedReader(new InputStreamReader(http.getInputStream()));
            while ((str = in.readLine()) != null){ 
                System.out.println(str);
            }
            in.close();
            
        } catch (MalformedURLException ex) {
            Logger.getLogger(Klijent.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Klijent.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    
    }

    private void napraviArtikl(String naziv, String opis, String cena, String popust, String prodavac, String kategorija) {
    
        try {
            String adresaURL="http://localhost:8080/Server/resources/podsistem2/dodajArtikal";
            int response=0;
            
            URL url=new URL(adresaURL);
            
            HttpURLConnection http = (HttpURLConnection) url.openConnection();
            
            http.setRequestMethod("POST");
            http.setDoOutput(true);
            
            String query="naziv="+naziv+"&opis="+opis+"&cena="+cena+"&popust="+popust+"&korisnik="+prodavac+"&idkategorija="+kategorija;
            
            
            OutputStream output = http.getOutputStream();
            output.write(query.getBytes());
            output.flush();
            
            response=http.getResponseCode();
            
            System.out.println("Status izvrenja:"+response);
            
            System.out.println("Odgovor:");
            
            String str=null;
            BufferedReader in = new BufferedReader(new InputStreamReader(http.getInputStream()));
            while ((str = in.readLine()) != null){ 
                System.out.println(str);
            }
            in.close();
            
        } catch (MalformedURLException ex) {
            Logger.getLogger(Klijent.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Klijent.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void promeniCenuArtikla(String idartikla, String cena) {
        
        try {
            String adresaURL="http://localhost:8080/Server/resources/podsistem2/promeniCenu";
            int response=0;
            
            URL url=new URL(adresaURL);
            
            HttpURLConnection http = (HttpURLConnection) url.openConnection();
            
            http.setRequestMethod("POST");
            http.setDoOutput(true);
            
            String query="idartikal="+idartikla+"&cena="+cena;
            
            
            OutputStream output = http.getOutputStream();
            output.write(query.getBytes());
            output.flush();
            
            response=http.getResponseCode();
            
            System.out.println("Status izvrenja:"+response);
            
            System.out.println("Odgovor:");
            
            String str=null;
            BufferedReader in = new BufferedReader(new InputStreamReader(http.getInputStream()));
            while ((str = in.readLine()) != null){ 
                System.out.println(str);
            }
            in.close();
            
        } catch (MalformedURLException ex) {
            Logger.getLogger(Klijent.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Klijent.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    
    
    
    }

    private void dodajPopust(String idartikla, String popust) {
       
        try {
            String adresaURL="http://localhost:8080/Server/resources/podsistem2/dodajPopust";
            int response=0;
            
            URL url=new URL(adresaURL);
            
            HttpURLConnection http = (HttpURLConnection) url.openConnection();
            
            http.setRequestMethod("POST");
            http.setDoOutput(true);
            
            String query="idartikal="+idartikla+"&popust="+popust;
            
            
            OutputStream output = http.getOutputStream();
            output.write(query.getBytes());
            output.flush();
            
            response=http.getResponseCode();
            
            System.out.println("Status izvrenja:"+response);
            
            System.out.println("Odgovor:");
            
            String str=null;
            BufferedReader in = new BufferedReader(new InputStreamReader(http.getInputStream()));
            while ((str = in.readLine()) != null){ 
                System.out.println(str);
            }
            in.close();
            
        } catch (MalformedURLException ex) {
            Logger.getLogger(Klijent.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Klijent.class.getName()).log(Level.SEVERE, null, ex);
        }
    
    }

    private void dodajUKorpu(String idkor, String idartikla, String kolicina) {
        try {
            String adresaURL="http://localhost:8080/Server/resources/podsistem2/dodajKorpu";
            int response=0;
            
            URL url=new URL(adresaURL);
            
            HttpURLConnection http = (HttpURLConnection) url.openConnection();
            
            http.setRequestMethod("POST");
            http.setDoOutput(true);
            
            String query="korisnik="+idkor+"&artikal="+idartikla+"&kolicina="+kolicina;
            
            
            OutputStream output = http.getOutputStream();
            output.write(query.getBytes());
            output.flush();
            
            response=http.getResponseCode();
            
            System.out.println("Status izvrenja:"+response);
            
            System.out.println("Odgovor:");
            
            String str=null;
            BufferedReader in = new BufferedReader(new InputStreamReader(http.getInputStream()));
            while ((str = in.readLine()) != null){ 
                System.out.println(str);
            }
            in.close();
            
        } catch (MalformedURLException ex) {
            Logger.getLogger(Klijent.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Klijent.class.getName()).log(Level.SEVERE, null, ex);
        }
    
    
    }

    private void obrisiIzKorpe(String korpa, String kolicina) {
   
        try {
            String adresaURL="http://localhost:8080/Server/resources/podsistem2/brisiKorpu";
            int response=0;
            
            URL url=new URL(adresaURL);
            
            HttpURLConnection http = (HttpURLConnection) url.openConnection();
            
            http.setRequestMethod("POST");
            http.setDoOutput(true);
            
            String query="korpa="+korpa+"&kolicina="+kolicina;
            
            
            OutputStream output = http.getOutputStream();
            output.write(query.getBytes());
            output.flush();
            
            response=http.getResponseCode();
            
            System.out.println("Status izvrenja:"+response);
            
            System.out.println("Odgovor:");
            
            String str=null;
            BufferedReader in = new BufferedReader(new InputStreamReader(http.getInputStream()));
            while ((str = in.readLine()) != null){ 
                System.out.println(str);
            }
            in.close();
            
        } catch (MalformedURLException ex) {
            Logger.getLogger(Klijent.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Klijent.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }

    private void transakcija(String korisnik) {
    
        try {
            String adresaURL="http://localhost:8080/Server/resources/podsistem3/napraviTransakciju";
            int response=0;
            
            URL url=new URL(adresaURL);
            
            HttpURLConnection http = (HttpURLConnection) url.openConnection();
            
            http.setRequestMethod("POST");
            http.setDoOutput(true);
            
            String query="kupac="+korisnik;
            
            
            OutputStream output = http.getOutputStream();
            output.write(query.getBytes());
            output.flush();
            
            response=http.getResponseCode();
            
            System.out.println("Status izvrenja:"+response);
            
            System.out.println("Odgovor:");
            
            String str=null;
            BufferedReader in = new BufferedReader(new InputStreamReader(http.getInputStream()));
            while ((str = in.readLine()) != null){ 
                System.out.println(str);
            }
            in.close();
            
        } catch (MalformedURLException ex) {
            Logger.getLogger(Klijent.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Klijent.class.getName()).log(Level.SEVERE, null, ex);
        }
    
    
    }

   /* private static String getCharacterDataFromElement(Element e) {
        Node child = e.getFirstChild();
        if (child instanceof CharacterData) {
            CharacterData cd = (CharacterData) child;
            return cd.getData();
        }
        return "?";
    }*/
    
    private void formatirajIspis(String str){
        String[] str_ispis=str.split(">");
        int i=0;
        for(String st:str_ispis){
            System.out.print(st+">");
            i++;
            if(i%2==1) System.out.println();
        }
    }
    
    
    private void dohvatiSveGradove()  {
        String adresa="http://localhost:8080/Server/resources/podsistem1/dohvatiGradove";
        int response=0;
        String ins=null;
        
        try {
            URL url=new URL(adresa);
            
            HttpURLConnection http;
            try {
                http = (HttpURLConnection)url.openConnection();
                http.setRequestMethod("GET");
                
                response=http.getResponseCode();
                
                System.out.println("Response kod je:"+response);
                
                System.out.println("Formatiran ispis:");
                
                
                BufferedReader input=new BufferedReader(new InputStreamReader(http.getInputStream()));
                while((ins=input.readLine())!=null){
                    
                    //System.out.println(ins);
                    formatirajIspis(ins);
                    
                }
                
                input.close();
                
                
                
                
            } catch (IOException ex) {
                Logger.getLogger(Klijent.class.getName()).log(Level.SEVERE, null, ex);
            }
            
            
        } catch (MalformedURLException ex) {
            Logger.getLogger(Klijent.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    
    }

    private void dohvatiSveKorisnike() {
    
        String adresa="http://localhost:8080/Server/resources/podsistem1/dohvatiKorisnike";
        int response=0;
        String ins=null;
        
        try {
            URL url=new URL(adresa);
            
            HttpURLConnection http;
            try {
                http = (HttpURLConnection)url.openConnection();
                http.setRequestMethod("GET");
                
                response=http.getResponseCode();
                
                System.out.println("Response kod je:"+response);
                
                System.out.println("Formatiran ispis:");
                
                
                BufferedReader input=new BufferedReader(new InputStreamReader(http.getInputStream()));
                while((ins=input.readLine())!=null){
                    
                    //System.out.println(ins);
                    formatirajIspis(ins);
                }
                
                input.close();
                
                
                
                
            } catch (IOException ex) {
                Logger.getLogger(Klijent.class.getName()).log(Level.SEVERE, null, ex);
            }
            
            
        } catch (MalformedURLException ex) {
            Logger.getLogger(Klijent.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void dohvatiSveKategorije() {
    
        String adresa="http://localhost:8080/Server/resources/podsistem2/dohvatiKategorije";
        int response=0;
        String ins=null;
        
        try {
            URL url=new URL(adresa);
            
            HttpURLConnection http;
            try {
                http = (HttpURLConnection)url.openConnection();
                http.setRequestMethod("GET");
                
                response=http.getResponseCode();
                
                System.out.println("Response kod je:"+response);
                
                System.out.println("Formatiran ispis:");
                
                
                BufferedReader input=new BufferedReader(new InputStreamReader(http.getInputStream()));
                while((ins=input.readLine())!=null){
                    
                    //System.out.println(ins);
                    formatirajIspis(ins);
                }
                
                input.close();
                
                
                
                
            } catch (IOException ex) {
                Logger.getLogger(Klijent.class.getName()).log(Level.SEVERE, null, ex);
            }
            
            
        } catch (MalformedURLException ex) {
            Logger.getLogger(Klijent.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    
    
    }

    private void dohvatiSveArtikleKorisnika(String ime, String prezime) {
        String adresa="http://localhost:8080/Server/resources/podsistem2/dohvatiArtikleKorisnika/"+ime+"/"+prezime;
        int response=0;
        String ins=null;
        
        try {
            URL url=new URL(adresa);
            
            HttpURLConnection http;
            try {
                http = (HttpURLConnection)url.openConnection();
                http.setRequestMethod("GET");
                
                response=http.getResponseCode();
                
                System.out.println("Response kod je:"+response);
                
                System.out.println("Formatiran ispis:");
                
                
                BufferedReader input=new BufferedReader(new InputStreamReader(http.getInputStream()));
                while((ins=input.readLine())!=null){
                    
                    //System.out.println(ins);
                    formatirajIspis(ins);
                }
                
                input.close();
                
                
                
                
            } catch (IOException ex) {
                Logger.getLogger(Klijent.class.getName()).log(Level.SEVERE, null, ex);
            }
            
            
        } catch (MalformedURLException ex) {
            Logger.getLogger(Klijent.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void dohvatiSadrzajKorpeKorisnika(String ime, String prezime) {
        String adresa="http://localhost:8080/Server/resources/podsistem2/dohvatiKorpu/"+ime+"/"+prezime;
        int response=0;
        String ins=null;
        
        try {
            URL url=new URL(adresa);
            
            HttpURLConnection http;
            try {
                http = (HttpURLConnection)url.openConnection();
                http.setRequestMethod("GET");
                
                response=http.getResponseCode();
                
                System.out.println("Response kod je:"+response);
                
                System.out.println("Formatiran ispis:");
                
                
                BufferedReader input=new BufferedReader(new InputStreamReader(http.getInputStream()));
                while((ins=input.readLine())!=null){
                    
                    //System.out.println(ins);
                    formatirajIspis(ins);
                }
                
                input.close();
                
                
                
                
            } catch (IOException ex) {
                Logger.getLogger(Klijent.class.getName()).log(Level.SEVERE, null, ex);
            }
            
            
        } catch (MalformedURLException ex) {
            Logger.getLogger(Klijent.class.getName()).log(Level.SEVERE, null, ex);
        }
    
    }

    private void dohvatiSveNarudbineKorisnika(String idKorisnika) {
        
        String adresa="http://localhost:8080/Server/resources/podsistem3/dohvatiNarudbinuKorisnika/"+idKorisnika;
        int response=0;
        String ins=null;
        
        try {
            URL url=new URL(adresa);
            
            HttpURLConnection http;
            try {
                http = (HttpURLConnection)url.openConnection();
                http.setRequestMethod("GET");
                
                response=http.getResponseCode();
                
                System.out.println("Response kod je:"+response);
                
                System.out.println("Formatiran ispis:");
                
                
                BufferedReader input=new BufferedReader(new InputStreamReader(http.getInputStream()));
                while((ins=input.readLine())!=null){
                    
                    //System.out.println(ins);
                    formatirajIspis(ins);
                }
                
                input.close();
                
                
                
                
            } catch (IOException ex) {
                Logger.getLogger(Klijent.class.getName()).log(Level.SEVERE, null, ex);
            }
            
            
        } catch (MalformedURLException ex) {
            Logger.getLogger(Klijent.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void dohvatiSveNarudbine() {
        String adresa="http://localhost:8080/Server/resources/podsistem3/dohvatiNarudbine";
        int response=0;
        String ins=null;
        
        try {
            URL url=new URL(adresa);
            
            HttpURLConnection http;
            try {
                http = (HttpURLConnection)url.openConnection();
                http.setRequestMethod("GET");
                
                response=http.getResponseCode();
                
                System.out.println("Response kod je:"+response);
                
                System.out.println("Formatiran ispis:");
                
                
                BufferedReader input=new BufferedReader(new InputStreamReader(http.getInputStream()));
                while((ins=input.readLine())!=null){
                    
                    //System.out.println(ins);
                    formatirajIspis(ins);
                }
                
                input.close();
                
                
                
                
            } catch (IOException ex) {
                Logger.getLogger(Klijent.class.getName()).log(Level.SEVERE, null, ex);
            }
            
            
        } catch (MalformedURLException ex) {
            Logger.getLogger(Klijent.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void dohvatiSveTransakcije() {
        String adresa="http://localhost:8080/Server/resources/podsistem3/dohvatiTransakcije";
        int response=0;
        String ins=null;
        
        try {
            URL url=new URL(adresa);
            
            HttpURLConnection http;
            try {
                http = (HttpURLConnection)url.openConnection();
                http.setRequestMethod("GET");
                
                response=http.getResponseCode();
                
                System.out.println("Response kod je:"+response);
                
                System.out.println("Formatiran ispis:");
                
                
                BufferedReader input=new BufferedReader(new InputStreamReader(http.getInputStream()));
                while((ins=input.readLine())!=null){
                    
                    //System.out.println(ins);
                    formatirajIspis(ins);
                }
                
                input.close();
                
                
                
                
            } catch (IOException ex) {
                Logger.getLogger(Klijent.class.getName()).log(Level.SEVERE, null, ex);
            }
            
            
        } catch (MalformedURLException ex) {
            Logger.getLogger(Klijent.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    
    
    
    
}
