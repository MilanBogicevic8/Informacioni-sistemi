/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package komanda;


import entities.Artikal;
import java.util.ArrayList;
import java.util.List;
import javax.jms.ObjectMessage;


/**
 *
 * @author Korisnik
 */
public class KomandaDohvatiArtikleKorisnika extends Komanda {

    private int idKorisnika;
    public KomandaDohvatiArtikleKorisnika(int i){
        idKorisnika=i;
    }
    
    @Override
    public ObjectMessage izvrsi() {
        
        ArrayList<Artikal> artikli=new ArrayList<>();
        List<Artikal> art=em.createNamedQuery("Artikal.findByKorisnik", Artikal.class).setParameter("korisnik", idKorisnika).getResultList();
        for(Artikal a:art){
              artikli.add(a);
        }
        ObjectMessage response=context.createObjectMessage(artikli);
        
        return response;
        
        
    }
    
}
