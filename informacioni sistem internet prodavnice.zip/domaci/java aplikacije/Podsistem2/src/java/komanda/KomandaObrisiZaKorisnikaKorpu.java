/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package komanda;

import entities.Korpa;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.TextMessage;
import javax.persistence.EntityExistsException;

/**
 *
 * @author Korisnik
 */
public class KomandaObrisiZaKorisnikaKorpu extends Komanda {

    private final int korisnik;

    public KomandaObrisiZaKorisnikaKorpu(int korisnik){
        this.korisnik=korisnik;
    }
    
    @Override
    public Message izvrsi() {
        TextMessage msg = null;
        try {
            
            
            String txt="Uspesna transakcija";
            int status=0;
            List<Korpa> korpa=em.createNamedQuery("Korpa.findByIdKorisnik", Korpa.class).setParameter("idKorisnik", korisnik).getResultList();
            for(Korpa k:korpa){
                try
                {
                    em.getTransaction().begin();
                    k.setKolicina(0);
                    k.setUkupnaCena(0);
                    em.getTransaction().commit();
                    status=0;
                }
                catch(EntityExistsException e)
                {
                    txt = "Korpa neuspeh!";
                    status = -1;
                    break;
                }
                finally
                {
                    if (em.getTransaction().isActive())
                        em.getTransaction().rollback();
                }
            }
            
            msg = context.createTextMessage(txt);
            msg.setIntProperty("status", status);
            
        } catch (JMSException ex) {
            Logger.getLogger(KomandaObrisiZaKorisnikaKorpu.class.getName()).log(Level.SEVERE, null, ex);
        }
        return msg;
    }
    
}
