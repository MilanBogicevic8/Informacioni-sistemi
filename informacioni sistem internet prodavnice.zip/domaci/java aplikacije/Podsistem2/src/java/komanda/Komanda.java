/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package komanda;

import java.io.Serializable;
import javax.jms.JMSContext;
import javax.jms.Message;
import javax.jms.TextMessage;
import javax.persistence.EntityManager;

/**
 *
 * @author Korisnik
 */
public abstract class Komanda implements Serializable {
    EntityManager em;
    JMSContext context;
    
    
    public Komanda(){}
    abstract public Message izvrsi();
    public void setEntityManager(EntityManager entity){
        this.em=entity;
    }
    
    public void setJMSContext(JMSContext jms){
        this.context=jms;
    }
}
