/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package komanda;

import entities.Artikal;
import entities.Korpa;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.TextMessage;
import javax.persistence.EntityExistsException;

/**
 *
 * @author Korisnik
 */
public class KomandaDodajArtikleUKorpu extends Komanda {

    private final String idartikal;
    private final String kolicina;
    private final String idkorisnika;

    public KomandaDodajArtikleUKorpu(String idartikal,String kolicina,String idkorisnika){
        this.idartikal=idartikal;
        this.kolicina=kolicina;
        this.idkorisnika=idkorisnika;
    }
    
    @Override
    public TextMessage izvrsi() {
        TextMessage msg = null;
        try {
            
            
            
            int status=0;
            String porukica="Artikal dodat u korpu";
            
            List<Artikal> artikli=em.createNamedQuery("Artikal.findByIdartikal", Artikal.class).setParameter("idartikal", Integer.parseInt(idartikal)).getResultList();
            
            Korpa korpa=new Korpa();
            korpa.setIdKorisnik(Integer.parseInt(idkorisnika));
            korpa.setKolicina(Integer.parseInt(kolicina));
            
            if(!artikli.isEmpty()){
                korpa.setIdartikal(artikli.get(0));
                Integer uCena=artikli.get(0).getCena()*(100-artikli.get(0).getPopust())*Integer.parseInt(kolicina)/100;
                korpa.setUkupnaCena(uCena);
                
                
                try
                {
                    em.getTransaction().begin();
                    em.persist(korpa);
                    em.getTransaction().commit();
                    status=0;
                }
                catch(EntityExistsException e)
                {
                    porukica = "Korpa vec postoji!";
                    status = -1;
                }
                finally
                {
                    if (em.getTransaction().isActive())
                        em.getTransaction().rollback();
                }
            }else{
                porukica="Nema tog artikla";
                status=-1;
            }
            
            
            
            msg = context.createTextMessage(porukica);
            msg.setIntProperty("status", status);
           
        } catch (JMSException ex) {
            Logger.getLogger(KomandaDodajArtikleUKorpu.class.getName()).log(Level.SEVERE, null, ex);
        }
        return msg;
    }
    
}
