/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package komanda;

import entities.Artikal;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.TextMessage;
import javax.persistence.EntityExistsException;

/**
 *
 * @author Korisnik
 */
public class KomandaPromeniCenu extends Komanda {

    private final String idartikal;
    private final String cena;
    private Integer id;
    
    public KomandaPromeniCenu(String idartikal,String cena){
        this.idartikal=idartikal;
        this.cena=cena;
        id=Integer.parseInt(idartikal);
    }
    
    @Override
    public TextMessage izvrsi() {
    
        TextMessage msg = null;
        try {
           
            
            String porukica;
            int status = 0;
            
            List<Artikal> artikli=em.createNamedQuery("Artikal.findByIdartikal", Artikal.class).setParameter("idartikal", id).getResultList();
            
            if(!artikli.isEmpty()){
                porukica="Artikal postoji";
                try
                {
                    em.getTransaction().begin();
                    Artikal artikal=artikli.get(0);
                    artikal.setCena(Integer.parseInt(cena));
                    em.getTransaction().commit();
                }
                catch(EntityExistsException e)
                {
                    porukica +="i nije dodata cena";
                    status = -1;
                }
                finally
                {
                    if (em.getTransaction().isActive())
                        em.getTransaction().rollback();
                }
                
                porukica+="i cena je promenjena.";
            }else{
                porukica="Ne postoji taj artikal";
                status=-1;
            }
            
            msg = context.createTextMessage(porukica);
            msg.setIntProperty("status", status);
            
            
        } catch (JMSException ex) {
            Logger.getLogger(KomandaPromeniCenu.class.getName()).log(Level.SEVERE, null, ex);
        }
        return msg;
    }
    
}
