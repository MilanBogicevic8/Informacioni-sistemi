/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package komanda;

import entities.Artikal;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.TextMessage;
import javax.persistence.EntityExistsException;

/**
 *
 * @author Korisnik
 */
public class KomandaDodajPopust extends Komanda {

    private final String idartikal;
    private final String popust;

    
    public KomandaDodajPopust(String idartikal,String popust){
        this.idartikal=idartikal;
        this.popust=popust;
    }
    @Override
    public Message izvrsi() {
        String porukica;
        int status = 0;
        
        List<Artikal> artikli=em.createNamedQuery("Artikal.findByIdartikal", Artikal.class).setParameter("idartikal", Integer.parseInt(idartikal)).getResultList();
        
        if(!artikli.isEmpty()){
            porukica="Artikal postoji";
            try
        {
            em.getTransaction().begin();
            Artikal artikal=artikli.get(0);
            artikal.setPopust(Integer.parseInt(popust));
            em.getTransaction().commit();
        }
        catch(EntityExistsException e)
        {
            porukica +="i nije dodat pop";
            status = -1;
        }
        finally
        {
            if (em.getTransaction().isActive())
                em.getTransaction().rollback();
        }
        
        porukica+="i popust je dodat.";
        }else{
            porukica="Ne postoji taj artikal";
            status=-1;
        }
        
        TextMessage msg = context.createTextMessage(porukica);
        try {
            msg.setIntProperty("status", status);
        } catch (JMSException ex) {
            Logger.getLogger(KomandaDodajPopust.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return msg;
        
    }
    
}
