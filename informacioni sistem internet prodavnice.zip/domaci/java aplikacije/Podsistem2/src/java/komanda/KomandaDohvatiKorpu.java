/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package komanda;

import entities.Korpa;
import java.util.ArrayList;
import java.util.List;
import javax.jms.Message;
import javax.jms.ObjectMessage;

/**
 *
 * @author Korisnik
 */
public class KomandaDohvatiKorpu extends Komanda {

    Integer korisnik;
    public KomandaDohvatiKorpu(int idkor){
        korisnik=idkor;
    }
    @Override
    public Message izvrsi() {
    
        ArrayList<Korpa> korpa=new ArrayList<>();
        List<Korpa> kor=em.createNamedQuery("Korpa.findByIdKorisnik", Korpa.class).setParameter("idKorisnik", korisnik).getResultList();
        for(Korpa k:kor){
              korpa.add(k);
        }
        
        ObjectMessage response=context.createObjectMessage(korpa);
        
        return response;
    }
    
}
