/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package komanda;

import entities.Artikal;
import entities.Kategorija;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.TextMessage;
import javax.persistence.EntityExistsException;

/**
 *
 * @author Korisnik
 */
public class KomandaKreiranjeArtikla extends Komanda {

    private String naziv;
    private String opis;
    private String cena;
    private String popust;
    private String korisnik;
    private String idKategorije;

    public KomandaKreiranjeArtikla(){}
    
    public KomandaKreiranjeArtikla(String naziv,String opis,String cena,String popust,String korisnik,String idKategorije){
        this.naziv=naziv;
        this.opis=opis;
        this.cena=cena;
        this.popust=popust;
        this.korisnik=korisnik;
        this.idKategorije=idKategorije;
        
    }

    @Override
    public Message izvrsi() {
        TextMessage msg = null;
        try {
            
            String txt = "Artikal dodat!";
            int status = 0;
            List<Kategorija> kategorija=em.createNamedQuery("Kategorija.findByIdkategorija", Kategorija.class).setParameter("idkategorija", Integer.parseInt(idKategorije)).getResultList();
            if(!kategorija.isEmpty()){
                
                
                Artikal artikal=new Artikal();
                artikal.setNaziv(naziv);
                artikal.setOpis(opis);
                artikal.setCena(Integer.parseInt(cena));
                artikal.setPopust(Integer.parseInt(popust));
                artikal.setKorisnik(Integer.parseInt(korisnik));
                artikal.setIdkategorija(kategorija.get(0));
                
                try
                {
                    em.getTransaction().begin();
                    em.persist(artikal);
                    em.getTransaction().commit();
                    status=0;
                }
                catch(EntityExistsException e)
                {
                    txt = "Artikal vec postoji!";
                    status = -1;
                }
                finally
                {
                    if (em.getTransaction().isActive())
                        em.getTransaction().rollback();
                }
            }else{
                txt="Vec postoji";
                status=-1;
            }
            
            msg = context.createTextMessage(txt);
            msg.setIntProperty("status", status);
            
            
                
        } catch (JMSException ex) {
            Logger.getLogger(KomandaKreiranjeArtikla.class.getName()).log(Level.SEVERE, null, ex);
        }
        return msg;
    }
    
}
