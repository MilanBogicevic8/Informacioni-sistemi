/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package komanda;

import entities.Kategorija;
import java.util.ArrayList;
import java.util.List;
import javax.jms.Message;
import javax.jms.ObjectMessage;
import javax.jms.TextMessage;

/**
 *
 * @author Korisnik
 */
public class KomandaDohvatiKategorije extends Komanda {

    @Override
    public ObjectMessage izvrsi() {
        ArrayList<Kategorija> kategorije=new ArrayList<>();
        List<Kategorija> kat=em.createNamedQuery("Kategorija.findAll", Kategorija.class).getResultList();
        for(Kategorija k:kat){
              kategorije.add(k);
        }
        ObjectMessage response=context.createObjectMessage(kategorije);
        
        return response;
    }
    
}
