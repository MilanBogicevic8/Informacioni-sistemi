/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package komanda;

import entities.Korpa;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.TextMessage;
import javax.persistence.EntityExistsException;

/**
 *
 * @author Korisnik
 */
public class KomandaBrisanjeIzKorpe extends Komanda {

    private final String korpa;
    private final String kolicina;

    
    public KomandaBrisanjeIzKorpe(String korpa,String kolicina){
       this.korpa=korpa;
       this.kolicina=kolicina;
       
    }
    
    @Override
    public Message izvrsi() {
        
        TextMessage msg = null;
        
        try {
            
            
            
            String txt="Promenjena vrednost";
            int status=0;
            Korpa korpa=em.find(Korpa.class, Integer.parseInt(this.korpa));
            if(korpa==null){
                txt="Nema te korpe";
                status=-1;
            }else{
                int k=korpa.getKolicina();
                int kol=Integer.parseInt(this.kolicina);
                if(k>kol){
                    try
                    {
                        em.getTransaction().begin();
                        korpa.setKolicina(k-kol);
                        korpa.setUkupnaCena(((k-kol)*(korpa.getUkupnaCena()/k)));
                        em.getTransaction().commit();
                        status=0;
                    }
                    catch(EntityExistsException e)
                    {
                        txt = "Korpa vec postoji!";
                        status = -1;
                    }
                    finally
                    {
                        if (em.getTransaction().isActive())
                            em.getTransaction().rollback();
                    }
                }else{
                    
                    
                    try
                    {
                        em.getTransaction().begin();
                        em.remove(korpa);
                        em.flush();
                    
                        em.getTransaction().commit();
                        status=0;
                        txt="Obrisana cela korpa";
                    }
                    catch(EntityExistsException e)
                    {
                        txt = "Korpa vec postoji!";
                        status = -1;
                    }
                    finally
                    {
                        if (em.getTransaction().isActive())
                            em.getTransaction().rollback();
                    }
                    
                    
                }
            }
            
            
            msg = context.createTextMessage(txt);
            msg.setIntProperty("status", status);
        } catch (JMSException ex) {
            Logger.getLogger(KomandaBrisanjeIzKorpe.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return msg;
    }
    
}
