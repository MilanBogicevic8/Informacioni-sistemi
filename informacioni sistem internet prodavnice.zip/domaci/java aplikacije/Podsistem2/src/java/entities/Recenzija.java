/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entities;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Korisnik
 */
@Entity
@Table(name = "recenzija")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Recenzija.findAll", query = "SELECT r FROM Recenzija r"),
    @NamedQuery(name = "Recenzija.findByIdrec", query = "SELECT r FROM Recenzija r WHERE r.idrec = :idrec"),
    @NamedQuery(name = "Recenzija.findByOcena", query = "SELECT r FROM Recenzija r WHERE r.ocena = :ocena"),
    @NamedQuery(name = "Recenzija.findByOpis", query = "SELECT r FROM Recenzija r WHERE r.opis = :opis")})
public class Recenzija implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "idrec")
    private Integer idrec;
    @Basic(optional = false)
    @NotNull
    @Column(name = "ocena")
    private int ocena;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "opis")
    private String opis;
    @JoinColumn(name = "idartikal", referencedColumnName = "idartikal")
    @ManyToOne(optional = false)
    private Artikal idartikal;

    public Recenzija() {
    }

    public Recenzija(Integer idrec) {
        this.idrec = idrec;
    }

    public Recenzija(Integer idrec, int ocena, String opis) {
        this.idrec = idrec;
        this.ocena = ocena;
        this.opis = opis;
    }

    public Integer getIdrec() {
        return idrec;
    }

    public void setIdrec(Integer idrec) {
        this.idrec = idrec;
    }

    public int getOcena() {
        return ocena;
    }

    public void setOcena(int ocena) {
        this.ocena = ocena;
    }

    public String getOpis() {
        return opis;
    }

    public void setOpis(String opis) {
        this.opis = opis;
    }

    public Artikal getIdartikal() {
        return idartikal;
    }

    public void setIdartikal(Artikal idartikal) {
        this.idartikal = idartikal;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idrec != null ? idrec.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Recenzija)) {
            return false;
        }
        Recenzija other = (Recenzija) object;
        if ((this.idrec == null && other.idrec != null) || (this.idrec != null && !this.idrec.equals(other.idrec))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entities.Recenzija[ idrec=" + idrec + " ]";
    }
    
}
