/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entities;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Korisnik
 */
@Entity
@Table(name = "kupoprodaja")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Kupoprodaja.findAll", query = "SELECT k FROM Kupoprodaja k"),
    @NamedQuery(name = "Kupoprodaja.findByIdkupoProdaja", query = "SELECT k FROM Kupoprodaja k WHERE k.idkupoProdaja = :idkupoProdaja"),
    @NamedQuery(name = "Kupoprodaja.findByVreme", query = "SELECT k FROM Kupoprodaja k WHERE k.vreme = :vreme"),
    @NamedQuery(name = "Kupoprodaja.findByStaJe", query = "SELECT k FROM Kupoprodaja k WHERE k.staJe = :staJe")})
public class Kupoprodaja implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "idkupoProdaja")
    private Integer idkupoProdaja;
    @Basic(optional = false)
    @NotNull
    @Column(name = "vreme")
    @Temporal(TemporalType.TIMESTAMP)
    private Date vreme;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "staJe")
    private String staJe;
    @JoinColumn(name = "idnarudbina", referencedColumnName = "idnarudbina")
    @ManyToOne(optional = false)
    private Narudbina idnarudbina;

    public Kupoprodaja() {
    }

    public Kupoprodaja(Integer idkupoProdaja) {
        this.idkupoProdaja = idkupoProdaja;
    }

    public Kupoprodaja(Integer idkupoProdaja, Date vreme, String staJe) {
        this.idkupoProdaja = idkupoProdaja;
        this.vreme = vreme;
        this.staJe = staJe;
    }

    public Integer getIdkupoProdaja() {
        return idkupoProdaja;
    }

    public void setIdkupoProdaja(Integer idkupoProdaja) {
        this.idkupoProdaja = idkupoProdaja;
    }

    public Date getVreme() {
        return vreme;
    }

    public void setVreme(Date vreme) {
        this.vreme = vreme;
    }

    public String getStaJe() {
        return staJe;
    }

    public void setStaJe(String staJe) {
        this.staJe = staJe;
    }

    public Narudbina getIdnarudbina() {
        return idnarudbina;
    }

    public void setIdnarudbina(Narudbina idnarudbina) {
        this.idnarudbina = idnarudbina;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idkupoProdaja != null ? idkupoProdaja.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Kupoprodaja)) {
            return false;
        }
        Kupoprodaja other = (Kupoprodaja) object;
        if ((this.idkupoProdaja == null && other.idkupoProdaja != null) || (this.idkupoProdaja != null && !this.idkupoProdaja.equals(other.idkupoProdaja))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entities.Kupoprodaja[ idkupoProdaja=" + idkupoProdaja + " ]";
    }
    
}
