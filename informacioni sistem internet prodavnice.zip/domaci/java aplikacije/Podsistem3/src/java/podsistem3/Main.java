/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package podsistem3;

import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.Resource;
import javax.jms.ConnectionFactory;
import javax.jms.JMSConsumer;
import javax.jms.JMSContext;
import javax.jms.JMSException;
import javax.jms.JMSProducer;
import javax.jms.Message;
import javax.jms.ObjectMessage;
import javax.jms.Queue;
import javax.jms.Topic;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import komanda.Komanda;

/**
 *
 * @author Korisnik
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    
    static EntityManagerFactory emf = Persistence.createEntityManagerFactory("Podsistem3PU");
    static EntityManager em = emf.createEntityManager();
    
    @Resource(lookup = "connFactory1")
    static ConnectionFactory connFactory;
    
    @Resource(lookup="server1")
    static Topic topic;
    
    @Resource(lookup="red1")
    static Queue queue;
    
    static JMSContext context;
    static JMSConsumer consumer;
    static JMSProducer producer;
    
    
    void obrada(){
        while(true){
            try {
                System.out.println("Podsistem3..");
                ObjectMessage msg = (ObjectMessage) consumer.receive();
                
                int zahtev = msg.getIntProperty("zahtev");
                
                
                Message response = null;
                
                Komanda komanda=(Komanda)msg.getObject();
                komanda.setEntityManager(em);
                komanda.setJMSContext(context);
                
                response=komanda.izvrsi();
                
                
                producer.send(queue,response);
            } catch (JMSException ex) {
                Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    
    public static void main(String[] args) {
        try{
        String msgSelector = "pod=3";
        context = connFactory.createContext();
        context.setClientID("3");
        consumer = context.createDurableConsumer(topic, "sub3", msgSelector, false);
        producer = context.createProducer();
        
        Main obr=new Main();
        obr.obrada();
        }catch(Throwable t){
            t.printStackTrace();
        }finally{
        em.close();
        }
    }
    
}
