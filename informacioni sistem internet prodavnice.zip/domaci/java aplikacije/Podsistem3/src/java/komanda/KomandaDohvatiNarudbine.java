/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package komanda;

import entities.Kupoprodaja;
import entities.Narudbina;
import java.util.ArrayList;
import java.util.List;
import javax.jms.Message;
import javax.jms.ObjectMessage;

/**
 *
 * @author Korisnik
 */
public class KomandaDohvatiNarudbine extends Komanda {

    
    public KomandaDohvatiNarudbine(){
        
    }
    
    @Override
    public Message izvrsi() {
    
        ArrayList<Narudbina> narudbina=new ArrayList<>();
        List<Narudbina> nar=em.createNamedQuery("Narudbina.findAll",Narudbina.class).getResultList();
        for(Narudbina n:nar){
            narudbina.add(n);
        }
        ObjectMessage response=context.createObjectMessage(narudbina);
        
        return response;
    }
    
}
