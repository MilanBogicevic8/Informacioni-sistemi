/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package komanda;

import entities.Kupoprodaja;
import entities.Narudbina;
import java.util.ArrayList;
import java.util.List;
import javax.jms.Message;
import javax.jms.ObjectMessage;

/**
 *
 * @author Korisnik
 */
public class KomandaDohvatiNarudbineKorisnika extends Komanda {

    private final String idKor;

    
    
    public KomandaDohvatiNarudbineKorisnika(String idKor){
        this.idKor=idKor;
    }
    
    @Override
    public Message izvrsi() {
    
        ArrayList<Narudbina> narudbina=new ArrayList<>();
        List<Kupoprodaja> kup=em.createNamedQuery("Kupoprodaja.findAll",Kupoprodaja.class).getResultList();
        for(Kupoprodaja k:kup){
              if(k.getStaJe().split("-")[1].equals(idKor)){
                  narudbina.add(k.getIdnarudbina());
              }
        }
        ObjectMessage response=context.createObjectMessage(narudbina);
        
        return response;
    
    }
    
}
