/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package komanda;

import entities.Korpa;
import entities.Kupoprodaja;
import entities.Narudbina;
import entities.Stavka;
import java.security.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.TextMessage;
import javax.persistence.EntityExistsException;

/**
 *
 * @author Korisnik
 */
public class KomandaPraviTransakciju extends Komanda {

    private final ArrayList<Korpa> korpa;
    private final Integer kupac;
    private final String grad;
    private final String adresa;

    public KomandaPraviTransakciju(ArrayList<Korpa> korpa,Integer kupac,String grad,String adresa){
        this.korpa=korpa;
        this.kupac=kupac;
        this.grad=grad;
        this.adresa=adresa;
    }
    @Override
    public Message izvrsi() {
        TextMessage msg=null;
        int status=0;
        String txt=null;
        
        //kreiranje narudbina
        int fl=0;//provera da li smo vec kupili te proizvode
        for(Korpa k:korpa){
            if(k.getKolicina()!=0 && k.getUkupnaCena()!=0){
                fl=1;
                break;
            }
        }
        if(fl==0){
            msg=context.createTextMessage("Vec si kupio to");
                try {
                    msg.setIntProperty("status",-1);
                } catch (JMSException ex) {
                    Logger.getLogger(KomandaPraviTransakciju.class.getName()).log(Level.SEVERE, null, ex);
                }
            return msg;
        }
        Narudbina narudbina=new Narudbina();
        int cena=0;
        for(Korpa k:korpa){
            cena+=k.getUkupnaCena();
        }
        narudbina.setCena(cena);
        
        //Timestamp datum = new Timestamp(System.currentTimeMillis());
        Date date=new Date();
        narudbina.setVreme(date);
        
        narudbina.setAdresa(adresa);
        narudbina.setGrad(grad);
        
        try
       {
            em.getTransaction().begin();
            em.persist(narudbina);
            em.flush();
            em.getTransaction().commit();
                    
        }
        catch(EntityExistsException e)
        {
            txt = "Narudbina neuspeh!";
            status = -1;
        }
         finally
        {
            if (em.getTransaction().isActive())
                em.getTransaction().rollback();
        }
       
        if(status==-1){
            try {
                msg = context.createTextMessage(txt);
                msg.setIntProperty("status", status);
                return msg;
            } catch (JMSException ex) {
                Logger.getLogger(KomandaPraviTransakciju.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
        
        
        //kreiranje stavki
        for(Korpa k:korpa){
            if(k.getKolicina()==0 || k.getUkupnaCena()==0) continue;
            Stavka stavka=new Stavka();
            stavka.setCena(k.getUkupnaCena()/k.getKolicina());
            stavka.setKolicina(k.getKolicina());
            stavka.setIdartikal(k.getIdartikal().getIdartikal());
            stavka.setIdnarudbina(narudbina);
            try
                {
                    em.getTransaction().begin();
                    em.persist(stavka);
                    em.getTransaction().commit();
                    
                }
                catch(EntityExistsException e)
                {
                    txt = "Stavka neuspeh!";
                    status = -1;
                    break;
                }
                finally
                {
                    if (em.getTransaction().isActive())
                        em.getTransaction().rollback();
                }
        }
        
        if(status==-1){
            try {
                msg = context.createTextMessage(txt);
                msg.setIntProperty("status", status);
                return msg;
            } catch (JMSException ex) {
                Logger.getLogger(KomandaPraviTransakciju.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
        //kreiranje transakcija
        
        Kupoprodaja kupoprodaja=new Kupoprodaja();
        kupoprodaja.setIdnarudbina(narudbina);
        kupoprodaja.setStaJe("kupac"+"-"+kupac);
        date=new Date();
        kupoprodaja.setVreme(date);
        
         try
       {
            em.getTransaction().begin();
            em.persist(kupoprodaja);
            em.getTransaction().commit();
                    
        }
        catch(EntityExistsException e)
        {
            txt = "Kupoprodaja neuspeh!";
            status = -1;
        }
         finally
        {
            if (em.getTransaction().isActive())
                em.getTransaction().rollback();
        }
       
        if(status==-1){
            try {
                msg = context.createTextMessage(txt);
                msg.setIntProperty("status", status);
                return msg;
            } catch (JMSException ex) {
                Logger.getLogger(KomandaPraviTransakciju.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
        
        
        
        
        //jos samo promena stanje racuna kupca i prodavaca da promenim
        
        //neka to bude kao odvojen zahtev u posebnoj komandi
        
        msg=context.createTextMessage(txt);
        try {
            msg.setIntProperty("status",status);
        } catch (JMSException ex) {
            Logger.getLogger(KomandaPraviTransakciju.class.getName()).log(Level.SEVERE, null, ex);
        }
        return msg;
    }
    
}
