/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package komanda;

import entities.Kupoprodaja;
import entities.Narudbina;
import java.util.ArrayList;
import java.util.List;
import javax.jms.Message;
import javax.jms.ObjectMessage;

/**
 *
 * @author Korisnik
 */
public class KomandaDohvatiTransakcije extends Komanda {

    
    public KomandaDohvatiTransakcije(){
        
    }
    @Override
    public Message izvrsi() {
    
        ArrayList<Kupoprodaja> kupoprodaja=new ArrayList<>();
        List<Kupoprodaja> kup=em.createNamedQuery("Kupoprodaja.findAll",Kupoprodaja.class).getResultList();
        for(Kupoprodaja k:kup){
            kupoprodaja.add(k);
        }
        ObjectMessage response=context.createObjectMessage(kupoprodaja);
        
        return response;
    }
    
}
